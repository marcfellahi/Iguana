require('filehandling')
require('LdIguanaFileLibrary')
require('stringutil')

local function trace(a,b,c,d) return end

local deliverymatch      = 'DELIVERYX12850:'
local incomingfile       = "X12850"
local replacedmatch      = 'REPLACEMENTX12850'
local sourcedirectory    = [[\\logiapp\Version\LogiDataRE\]]

trace(sourcedirectory)

function main()
   
   local data
   local filenames = scandir(sourcedirectory)

   if filenames ~= nil then
   
      for i=1,#filenames do
            
         uppername = filenames[i]:upper()

         if uppername:find(incomingfile) ~= nil then
            
            k, j = uppername:find(incomingfile)
            
            local filetobeprocessed = string.upper(string.sub(filenames[i],k,j+4))
            --print('Filename: ',filetobeprocessed)

            local DeliveryShipmentCode = findtextinfile(sourcedirectory..filetobeprocessed,deliverymatch)
            
            if DeliveryShipmentCode ~= nil then
               
               data = ProcessFile(sourcedirectory, filetobeprocessed, replacedmatch, DeliveryShipmentCode, deliverymatch)
               
            end

            if not iguana.isTest() then

               if DeliveryShipmentCode ~= nil then
                  
                  queue.push{data=data}      
               
               end
            
               removeFile(sourcedirectory..filetobeprocessed)      
               
            end         
         end

      end

   end

end


function ProcessFile(directory, file, replacedtext, deliverytext, striptextPO)

   local data           = ''
   local fileandpath    = directory..file
   
   local fileopen = assert(io.open(fileandpath, "r"), "Could not open file: "..fileandpath)
            
   if fileopen ~= nil then
      
      for line in fileopen:lines() do

         if line:find(replacedtext) ~= nil then
         
            data = data..line:gsub(replacedtext,deliverytext)..'\r\n'
            trace(data)

         else
            
            if line:find(striptextPO) ~= nil then            
            
               data = data..line:sub(1,line:find(striptextPO)-2)..'\r\n'
               trace(data)
         
            else
            
               data = data..line..'\r\n'
               trace(data)
      
            end
          
         end
      

      end
      
      io.close(fileopen)
      
   end
   
   --print('complete segment: ',data)

   return data

end

function scandir(directory)
   
   local counter = 1
   local nameindex = {}
   
   
   local filenames = io.popen('dir /b '..directory)
   trace(filenames)
   local Status, list = pcall(ReadDir,filenames)
   
   trace(Status,listread)
   
   if not Status then
      return nil
   end
   
   --local list      = filenames:read('*a')
   
   for k,v in pairs(list:split('\n')) do

      local listname = v:upper()
      
      if listname:find('X12850') ~= nil then
      
         nameindex[counter] = v
         counter = counter + 1

      end
      
   end
   
   trace(nameindex)
      
   return nameindex
   
end

function ReadDir(filenameread)
   
   return filenameread:read('*a')
   
end
