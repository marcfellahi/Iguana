require('strings')

local function trace(a,b,c,d) return end

function main (Data)
      
   local FILE_PATTERN = 'x12850.*' 
   local OUTPUT_DIR=[[\\logiapp\Logireq\Temp\CCrep]]
   local nameIndex = {} 
   local filePath=OUTPUT_DIR..'\\'
   -- if running on Win then command to use is 'dir /b'
   -- on different os command will be different

   local counter = 1
   local filecounter
   local fileextnumeric
   local P = io.popen('dir '..filePath..FILE_PATTERN..' /b')
   local List = P:read('*a')
   
   trace(List)
   
   for k, v in pairs (List:split('\n')) do 
   
      fileextnumeric = false
      nameIndex=v
      
      trace(nameIndex)
      
      if nameIndex:find('%.') ~= nil then
     
         trace(nameIndex:sub(nameIndex:find('%.')))
         fileextnumeric = assert(type(nameIndex:sub(nameIndex:find('%.')+1)+0) == "number", "this file extension is not numeric")

         if fileextnumeric then
         
            filecounter = nameIndex:sub(nameIndex:find('%.')+1)+0
            
            trace(filecounter, counter, filecounter == counter)
         
            if filecounter == counter then
            
               counter = counter + 1
            
            end
            
         end
         
      end

   end
     
   trace(counter)
         
   nameIndex='x12850.'..tostring(counter):zfill(3)
   
   -- enhance name Index as desired ....
   
   local fn=filePath..tostring(nameIndex)
   
   trace(fn)
   
   if not iguana.isTest() then
   
      writeBinary(fn,Data)
      
   end
   
end

function writeBinary(fn,binData)
   local f = io.open(fn, "wb")
   f:write(binData)
   f:close()   
end