require('filehandling')
require('LdIguanaFileLibrary')
require('stringutil')

local function trace(a,b,c,d) return end

local incomingfile       = "X12850"
sourcedirectory    = [[\\logiapp\Version\LogiDataRE\]]

trace(sourcedirectory)

function main()
   
   local data
   local filenames = scandir(sourcedirectory)  

   if filenames ~= nil then
   
      for i=1,#filenames do
            
         uppername = filenames[i]:upper()

         if uppername:find(incomingfile) ~= nil then
            
            k, j = uppername:find(incomingfile)
            
            local filetobeprocessed = string.upper(string.sub(filenames[i],k,j+4))
            --print('Filename: ',filetobeprocessed)

            jsondata = RetrieveInfo(sourcedirectory,filetobeprocessed)
            trace(jsondata)
            NbrCostCenters = Process_WorkCenters(jsondata)

            local ReplExt = 0
            replnumber = ''
            
            trace(#NbrCostCenters)
            
            for i=1,#NbrCostCenters do

               if #NbrCostCenters > 1 then

                  ReplExt = ReplExt + 1
                  
               end
               
               ReqData = BuildHeader(jsondata,NbrCostCenters[i],ReplExt)
               ReqData = ProcessFile(ReqData,jsondata,NbrCostCenters[i])
               
               trace(ReqData)
               
               if not iguana.isTest() then 
               
                  queue.push{data=ReqData}      
     
               end         
               
            end
            
            if not iguana.isTest() then
               removeFile(sourcedirectory..filetobeprocessed)       
            end
                  
         end

      end

   end

end


function BuildFooter(Header,NbrLines,TotQty)
  
   local currentdate = os.date("%y%m%d")
   Header = Header..
   'CTT^'..NbrLines..'^'..TotQty..'\r\n'
   Header = Header..
   'SE^1\r\n'
   Header = Header..
   'GE^1\r\n'
   Header = Header..
   'IEA^1\r\n'
   
   trace(Header)
   
   return Header
   
end


function BuildHeader(json,CostCenter,ReplenExt)
   
   local currentdate = os.date("%y%m%d")
   local currenttime = os.date("%H%M")
   
   if ReplenExt > 0 then
      replnumber = json[1].ReplNumber..'-'..ReplenExt
   else
      replnumber = json[1].ReplNumber
   end
   
   local Header = 'ISA^00^'..string.format("% 10s",'')..'^00^'..string.format("% 10s",'')
   ..'^01^'..string.format("%-15s",'LOGID')..'^01^'..string.format("%-15s",'ConCORD HEMM')..'^'..currentdate..'^'
   ..currenttime..'^U^00204^'..string.format("%09s",replnumber)..'^^P^^\r\n'
   Header = Header..
   'GS^^LOGID^NOVAIDN^'..currentdate..'^'..currenttime..'^^X^00204\r\n'
   Header = Header..
   'ST^850^'..replnumber..'\r\n'
   Header = Header..
   'BEG^00^SA^L'..replnumber..'^'..currentdate..'\r\n'
   Header = Header..
   'DTM^097^'..currentdate..'^'..currenttime..'\r\n'
   Header = Header..
   'N1^BY^^92^'..CostCenter..'^1000^1222\r\n'
   Header = Header..
   'N1^ST^'..json[1].ShipTo..'^92^\r\n'
   
   trace(Header)
   
   return Header
   
end


function EscapeCharacters(fileesc)

   local readline = ''
   local readpos  = fileesc:seek()
   local matches  =
   {
      [">"] = "&gt;";
      ["<"] = "&lt;";
      ['"'] = "&quot;";
      ["&"] = "&amp;";
      ["'"] = "&apos;";

   }

   for line in fileesc:lines() do

      if #line ~= 1 and line ~= lines then
         
         if line:find(":") ~= nil then
            
            local extractfirstpart = line:sub(1,line:find(":"))
            local extractscndpart  = line:sub(line:find(":")+1)

            extractscndpart = extractscndpart:gsub("[><'&]",matches)
            trace(extractfirstpart,extractscndpart,matches)
     
            readline = readline..extractfirstpart.."'"..extractscndpart.."',\r\n"
            
         else
            
            readline = readline..line.."\r\n"
            
         end
      else
         
         readline = readline..line.."\r\n"
         
      end
      
   end
   
   trace(readline)

   fileesc:seek("set",readpos)
   
   return readline
   
end
   

function ProcessFile(header,jsoninfo,costcenter)

   line = 0
   TotalQty = 0
  
   for i=1,#jsoninfo do
   
      if jsoninfo[i].CostCenter == costcenter then
         
         line = line + 1
         TotalQty = TotalQty + jsoninfo[i].QtyOrd
         header = header..
         'PO1^'..line..'^'..jsoninfo[i].QtyOrd..'^'..string.format("%2s",jsoninfo[i].ProdUnit)..
         '^^^^^^^^^^^BP^'..jsoninfo[i].ProdCode..'^^^DV^\r\n'
         
         if jsoninfo[i].ProdSerialLot ~= '' then
            
            header = header..
            'NTE^SER: '..jsoninfo[i].ProdSerialLot..'\r\n'
            
         end
         
      end
         
   end

   header = BuildFooter(header,line,TotalQty)

   trace(header)
   
   return header
   
end


function Process_WorkCenters(jsondata)

   local SortedCenters = {}
   
   for i=1,#jsondata do
   
      local AddCostCenter = true
   
      trace(jsondata[i].ItemCostCenter,jsondata[i].CostCenter)
      
      if jsondata[i].ItemCostCenter ~= '' then
         jsondata[i].CostCenter = jsondata[i].ItemCostCenter
      end
      
      trace(jsondata[i].CostCenter)
      
      for j=1,#SortedCenters do
         
         if jsondata[i].CostCenter == SortedCenters[j] then
            AddCostCenter = false
            break
         end


      end
      
      if AddCostCenter then
         SortedCenters[#SortedCenters+1] = jsondata[i].CostCenter
      end
         
   end
   
   trace(SortedCenters)
   
   return SortedCenters
   
end

function RetrieveInfo(directory, file)

   local data           = ''
   local fileandpath    = directory..file

   local fileopen = assert(io.open(fileandpath, "r"), "Could not open file: "..fileandpath)

   local CostCenter = ''
   local Shipto = ''

   readlines = EscapeCharacters(fileopen)
   trace(readlines)

   local jsondata = json.parse{data=readlines}

   fileopen:close()
   
   return jsondata
   
end


function scandir(directory)
   
   local counter = 1
   local nameindex = {}
   
   
   local filenames = io.popen('dir /b '..directory)
   trace(filenames)
   
   if filenames == nil then
      return nil
   end
   
   local list      = filenames:read('*a')
    
   for k,v in pairs(list:split('\n')) do

      local listname = v:upper()
      
      if listname:find('X12850') ~= nil then
      
         nameindex[counter] = v
         counter = counter + 1

      end
      
   end
   
   trace(nameindex)
      
   return nameindex
   
end   
