require('retry')

function trace(a,b,c,d) return end
-- The main function is the first function called from Iguana.
-- The Data argument will contain the message to be processed.
function main(Data)
   
   local DataHeader = [[SECONDARY TAG(S) ALERT NOTIFICATION]]..'\n'..
   [[The following items with secondary tags have been put on board for replenishments:]]..'\n\n'      

   DataHeader = DataHeader..Data

   local configfile = [[C:\Program Files\iNTERFACEWARE\Iguana\iguanaconfiguration.xml]]
   local openconfig = io.open(configfile,'r')
   local readconfig = openconfig:read("*all")
   openconfig:close() 
   
   local parseconfig = xml.parse{data=readconfig}
   
   local emaillist = {}
   local k = 1
   
   for i=1,parseconfig.iguana_config.auth_config:childCount("user") do

      for j=1,parseconfig.iguana_config.auth_config:child("user",i).group:childCount() do
         
         trace(parseconfig.iguana_config.auth_config:child("user",i).email_address:nodeValue())
         
         if parseconfig.iguana_config.auth_config:child("user",i).group[j]:nodeValue() == 'Alerts Secondary Tags' then
            emaillist[k] = parseconfig.iguana_config.auth_config:child("user",i).email_address:nodeValue()
            k = k + 1
         end
         
      end
      
   end

     
   local smtpserver = parseconfig.iguana_config.email_config.smtp_host:nodeValue()
   local smtpport = parseconfig.iguana_config.email_config.smtp_port:nodeValue()
   local smtpsender = parseconfig.iguana_config.email_config.sender_email_address:nodeValue()
   local smtpuser = parseconfig.iguana_config.email_config.smtp_user_name:nodeValue()
   local smtppass = parseconfig.iguana_config.email_config.smtp_password:nodeValue()

   --net.smtp.send{
   
   trace(emaillist,DataHeader)
   
   if not iguana.isTest() then
      results = retry.call{func=sendmail,arg1=smtpserver,arg2=smtpsender,arg3=emaillist,
         arg4=DataHeader,retry=10,pause=10} 
      --results = net.smtp.send{server=smtpserver,from=smtpsender,to=emaillist,
      --   header={['Subject']='Logid System Stockout'},body=DataHeader,debug=true}
      trace(results)
   end
   
end

function sendmail(smtpserver,smtpsender,emaillist,DataHeader)

   trace(smtpserver,smtpsender,emaillist,DataHeader)
   
   --local results = net.smtp.send{server=smtpserver,from=smtpsender,to=emaillist,
   --   header={['Subject']='Logid System Stockout'},body=DataHeader,debug=true}
   
   local result = net.smtp.send{server=smtpserver,from=smtpsender,to=emaillist,
      header={['Subject']='Logid System Stockout'},body=DataHeader,debug=true}

   return result
   
end