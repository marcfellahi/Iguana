require('dbc')
require('iguanaconfig')

function trace(a,b,c,d) return end
-- This channel will check if a tag goes on board and it is a critical JIT items.  If it is, send an email to
-- the appropriate ressources
-- Marc Fellahi  2013/09/26
-- The main function is the first function called from Iguana.
function main()
   
   local minutes = os.date('%M') + 0
   local seconds = os.date('%S') + 0
      
   trace(minutes)
   
   if minutes > 1 then
      return
   end

   local Inbound  = io.open([[\\ldpilot01\Version\LogiDataExe\Interfaces\Medstar\inboundsettings.xml]]) 
   
   if Inbound == nil then
      return
   end
   
   local InboundFileRead = Inbound:read("*all") 
   Inbound:close()
   
   local Settings = {}
   Settings = Load_Messages(xml.parse{data=InboundFileRead})     

   trace(Settings, Msg)
   
   conn = dbc.Connection{         
         api=db.SQL_SERVER,
         name=Settings.DB_name[1],
         user=Settings.DB_username[1], 
         password=Settings.DB_password[1],
         use_unicode=true,
         live=true
         }
   
   --local UpdateWarning = [[UPDATE Logidata.ProduitDansCasier ]]..
   --[[SET UD2 = '' ]]--..
   --[[WHERE UD2 = 'Warning' and IDProduitDansCasier NOT IN (SELECT L.IDProduitDansCasier FROM Logidata.Lectures L ]]--..
   --[[JOIN Logidata.ProduitDansCasier PDC ON PDC.IDProduitDansCasier = L.IDProduitDansCasier ]]--..
   --[[JOIN Logidata.ProduitDeptLocal PDL ON PDL.IDProduit = PDC.IDProduit ]]--..
   --[[AND PDL.IdDepartement = PDC.IdDepartement AND PDL.IdLocal = PDC.IdLocal ]]--..
   --[[WHERE PDC.CodePrimaireOuSecondaire = 'S')]] 
   
   --local result = conn:execute(UpdateWarning)
   
   local QueryPDC = [[SELECT PDC.idProduitDansCasier, P.CodeProduit, P.Description , D.IdDepartement, ]]..
   [[D.Description [DeptDesc], LO.IdLocal, LO.Description [RoomDesc], ]]..
   [[(PDC.CodeArmoire + '.' + CAST(PDC.NoTiroir as varchar) + '.' + PDC.CodeCasier + '.' + PDC.CodePrimaireOuSecondaire) [Bin], ]]..
   [[PDC.QteDansCeCasier, PDL.UniteQuota ]]..
   [[FROM Logidata.Lectures L ]]..
   [[JOIN Logidata.ProduitDansCasier PDC ON PDC.IDProduitDansCasier = L.IDProduitDansCasier ]]..
   [[JOIN Logidata.ProduitDeptLocal PDL ON PDL.IDProduit = PDC.IDProduit AND ]]..
   [[PDL.IdDepartement = PDC.IdDepartement AND PDL.IdLocal = PDC.IdLocal ]]..
   [[JOIN Logidata.Produit P ON P.IDProduit = pdc.IDProduit ]]..
   [[JOIN Logidata.Departement D ON D.IdDepartement = PDC.IdDepartement ]]..
   [[JOIN Logidata.Locaux LO ON LO.IdDepartement = PDC.IdDepartement and LO.IdLocal = PDC.IdLocal ]]..
   --[[WHERE PDC.UD2 != 'Warning' AND PDC.CodePrimaireOuSecondaire = 'S' ]]--..
   [[AND PDC.CodePrimaireOuSecondaire = 'S' ]]..
   [[ORDER BY D.idDepartement, LO.idLocal, P.CodeProduit]]
   
   local result = conn:query(QueryPDC)
   
   trace(result)
   
   if not iguana.isTest() then

      local WarningLog = '' 

      local Department = ''
      
      for i=1,#result do

         if Department ~= (result[i].idDepartement..result[i].idLocal) then
            if Department ~= '' then
               WarningLog = WarningLog..'\n\n'
            end
            Department = result[i].idDepartement..result[i].idLocal
            WarningLog = WarningLog..[[Department/Room: (]]..result[i].idDepartement..[[) ]]..result[i].DeptDesc..[[ / (]]..
            result[i].idLocal..[[) ]]..result[i].RoomDesc..'\n\n'
         end
         
         WarningLog = WarningLog..[[Item (]]..result[i].CodeProduit..[[) ]]..
         string.format("%-50s ",result[i].Description:nodeValue()):sub(1,40)..
         --[[ Department/Room: (]]--..result[i].idDepartement..[[) ]]..result[i].DeptDesc..[[ / (]]..
         --result[i].idLocal..[[) ]]..result[i].RoomDesc..[[ Location: ]]..result[i].Bin..[[ Qty: ]]..
         [[ Location: ]]..result[i].Bin..[[ Qty: ]]..
         result[i].QteDansCeCasier..[[ ]]..result[i].UniteQuota..'\n'
         
         local UpdatePDC = [[UPDATE Logidata.ProduitDansCasier ]]..
         [[SET UD2 = 'Warning' ]]..
         [[WHERE idProduitDansCasier = ]]..result[i].idProduitDansCasier
         trace(UpdatePDC,WarningLog)      
         conn:execute(UpdatePDC)
         
      end   
      
      trace(WarningLog)
      
      if #result > 0 then
         if not iguana.isTest() then
            queue.push{data=WarningLog}
         end
      end
      
   end
    
end