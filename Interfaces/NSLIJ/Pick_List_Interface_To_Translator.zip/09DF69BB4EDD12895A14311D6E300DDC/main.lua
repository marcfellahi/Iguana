function trace(a,b,c,d) return end

-- The main function is the first function called from Iguana.
-- The Data argument will contain the message to be processed.
function main(Data)
   
   trace(Data)
   
   Data = Data:gsub('<PRODUCT_CODE/>','<PRODUCT_CODE>EXT_REF_ITEM</PRODUCT_CODE>')
   Data = Data:gsub('<PRODUCT_CODE></PRODUCT_CODE>','<PRODUCT_CODE>EXT_REF_ITEM</PRODUCT_CODE>')
   local Status, XMLparsed = pcall(Parse_XML,Data)

   if not Status then
      
      iguana.logError("PICK LIST ERROR - invalid XML.  Received: "..Data)
      return
      
   end

   trace(Status)
   
   local Status = pcall(Validate_XML,XMLparsed)
   --local Status = Validate_XML(XMLparsed)
   
   if not Status then
      iguana.logInfo("Pick LIST ERROR - Missing or Erronneous Case/Product Info.  Received:"..Data)
      return
   end
  
   local ItemsTable = {}
   
   for i=1,XMLparsed.PICK_SHEET_LOAD:childCount("CASE_INFO") do
      
      trace(XMLparsed.PICK_SHEET_LOAD[i].CASE_ID[1])
      jsondata = '{"existingCase":{"Code":"'..XMLparsed.PICK_SHEET_LOAD[i].CASE_ID[1]..'"},"items":['
      
      for index=1,XMLparsed.PICK_SHEET_LOAD[i]:childCount("PRODUCT_INFO") do
         
         trace(j)         

         local mattype = XMLparsed.PICK_SHEET_LOAD.CASE_INFO:child("PRODUCT_INFO",index).MAT_TYPE[1]:nodeValue()
         
         if mattype:upper() == 'SUPPLY' or mattype:upper() == 'IMPLANT' then
            
            jsondata = jsondata..'{"Code":"'..XMLparsed.PICK_SHEET_LOAD.CASE_INFO:child("PRODUCT_INFO", index).PRODUCT_CODE[1]:nodeValue()..
            '","Quantity":"'..XMLparsed.PICK_SHEET_LOAD.CASE_INFO:child("PRODUCT_INFO", index).QTY_TO_PICK[1]:nodeValue()..'",'..
            '"PRNQuantity":"'..XMLparsed.PICK_SHEET_LOAD.CASE_INFO:child("PRODUCT_INFO", index).PRN_QTY_TO_PICK[1]:nodeValue()..'"},'

            table.insert(ItemsTable, {Item=XMLparsed.PICK_SHEET_LOAD.CASE_INFO:child("PRODUCT_INFO", index).PRODUCT_CODE[1]:nodeValue(),
                  Description=XMLparsed.PICK_SHEET_LOAD.CASE_INFO:child("PRODUCT_INFO",index).DESCRIPTION[1]:nodeValue(),
                  QtyToPick=XMLparsed.PICK_SHEET_LOAD.CASE_INFO:child("PRODUCT_INFO", index).QTY_TO_PICK[1]:nodeValue(),
                  PRNQty=XMLparsed.PICK_SHEET_LOAD.CASE_INFO:child("PRODUCT_INFO", index).PRN_QTY_TO_PICK[1]:nodeValue(),
                  MaterialType=mattype:upper()})
         end
         
      end

      trace(ItemsTable)
      
      jsondata = jsondata..']}'
      
      trace(jsondata)
      
      local jsonparsed = json.parse{data=jsondata}
      trace(jsondata)

      Results = SendjsonData(jsonparsed)
      --Results = [[{"Result":false,"Message":"Could not find product for code 100499. Could not find product for code 105078. ]]..
      --   [[Could not find product for code 145699. Could not find product for code 20224"}]]
      if not iguana.isTest() then
         
         Resultsparse = json.parse{data=Results}
         
         if Resultsparse.Result then
            iguana.logInfo("LogiData CIRCUIT-iD Pick List SUCCESS -> Pick List Added to Case:"..jsonparsed.existingCase.Code)
         else               
            ResultsMessage = AddDescription(Resultsparse.Message,ItemsTable)
            if ResultsMessage ~= '' then
               iguana.logInfo("LogiData CIRCUIT-iD Pick List ERROR -> Case id: "..XMLparsed.PICK_SHEET_LOAD[i].CASE_ID[1]..'\n\n'..ResultsMessage)
            else
               iguana.logInfo("LogiData CIRCUIT-iD Pick List SUCCESS -> Pick List Added to Case:"..jsonparsed.existingCase.Code)
            end
         end
   
      end
      
   end
   

end

function AddDescription(message,listofitems)
   
   if message:find('No operation was found') ~= nil then
      return message
   end
   
   message = message..'.'
   
   local newmessage = ''
   local startpos = 1
   
   while message:find('code',startpos) ~= nil do
      startpositem = message:find('code',startpos)+5
      endpos = message:find('%.',startpos)
      item = message:sub(startpositem,endpos-1)
      trace(message:find('code'),startpos)
      
      for key,value in pairs(listofitems) do
         
         trace(key,listofitems[key].Description)
         trace(value.Item,item,value.Item==item,listofitems[key].Description)
         
         if listofitems[key].Item == item then
            trace(true,message:sub(startpos,endpos-1))
            newmessage = newmessage..message:sub(startpos,endpos-1)..' '..
            listofitems[key].Description..' ('..listofitems[key].MaterialType..
            ')  Open qty: '..listofitems[key].QtyToPick..'  PRN qty:'..
            listofitems[key].PRNQty..'\n\r'
            break
         end
         
      end
      
      startpos = endpos+2
      trace(newmessage..message,startpos)

   end
   
   return newmessage
   
end


function Parse_XML(XMLdata)
   
   return xml.parse{data=XMLdata}   
   
end

function POSTMessage(call,jsondata)

   return net.http.post{url='http://SYKPLOGIAP01V:82/import/'..call,
         --url="http://SVR-BEAMAX02:82/Import/"..functioncall,
         headers={'Content-Type:application/json','charset:utf-8'}, body=jsondata,live=true}
      
   
end

function Validate_XML(XMLdata)
   
   for i=1,XMLdata.PICK_SHEET_LOAD:childCount("CASE_INFO") do
   
      trace(XMLdata.PICK_SHEET_LOAD[i].CASE_ID[1])

      if XMLdata.PICK_SHEET_LOAD[i].CASE_ID[1] == '' then
         iguana.logError("PICK LIST ERROR - Invalid Case.  Received: "..XMLdata.PICK_SHEET_LOAD[i])
         return false
      end
      
     -- XMLdata.PICK_SHEET_LOAD.CASE_INFO:child("PRODUCT_INFO", 9).PRODUCT_CODE:setInner('EXT_REF_ITEM')

      for j =1,XMLdata.PICK_SHEET_LOAD.CASE_INFO:childCount("PRODUCT_INFO") do
         --trace(XMLdata.PICK_SHEET_LOAD[i]:child("PRODUCT_INFO",j).PRODUCT_CODE[1])

         trace(j,XMLdata.PICK_SHEET_LOAD.CASE_INFO:child("PRODUCT_INFO", j).PRODUCT_CODE[1])
                  
         if XMLdata.PICK_SHEET_LOAD.CASE_INFO:child("PRODUCT_INFO", j).PRODUCT_CODE[1]:nodeValue() == 'EXT_REF_ITEM' then
            XMLdata.PICK_SHEET_LOAD.CASE_INFO:child("PRODUCT_INFO", j).PRODUCT_CODE[1]:setInner('EXT_REF_ITEM'..j)
            trace(XMLdata.PICK_SHEET_LOAD.CASE_INFO:child("PRODUCT_INFO", j).PRODUCT_CODE[1])
            --iguana.logError("PICK LIST ERROR - Invalid Product Information.  Received: "..XMLdata.PICK_SHEET_LOAD[i])
            --return false            
         end   
  
      end

   end

   --trace(XMLdata.PICK_SHEET_LOAD.)
   trace(XMLdata)
   return true
   
end

function SendjsonData(data)
   
   functioncall = 'CreateItemPickSheet'

   local jsontransmit = json.serialize{data=data}
   local Status = ''
   
   if not iguana.isTest() then

      Status, Results = pcall(POSTMessage,functioncall,jsontransmit)

      trace(Results) 
      
      --if Results ~= nil and Results ~= '' then
      --   iguana.logInfo(Results)      
      --end
      
   end

   if not Status then
      Results = '{"Result":false,"Message":"Unknown error.  Please contact IT support."}'
   end
   
   trace(Results)
   
   return Results
   
end