require('stringutils')
require('DBOperations')
require('files')
require('iguanaconfig')
require('retry')
require('SMTPFunctions')

resubmit = require('resubmit')

function trace(a,b,c,d) return end

-- The main function is the first function called from Iguana.
-- The Data argument will contain the message to be processed.
function main(Data)
   
   local CSVData=parseCSV(Data)
   trace(CSVData)
   
   ProcessCSV(CSVData)
   
end

function parseCSV(Data)

   local CSVSplit=Data:split('\n')
   local CleanCSV={}
   local CSVTransform={}

   for i=1,#CSVSplit do
      
      CleanCSV[i]={}
      
      --print("bug: ",CSVTransform)
      CSVTransform=CSVSplit[i]:splitQ(',','"')
      --print("bug: ",CSVTransform)
      
      for j=1,#CSVTransform do 
      
         CleanCSV[i]=CSVTransform[j]:trimWS()
         
      end
      
   end

   return CleanCSV

end   

function ProcessCSV(Data)

   local MessFile = io.open([[\\sykplogiap01v\Version\LogiDataExe\Interfaces\PeopleSoft\messages.en.xml]])
   local MessFileRead = MessFile:read("*all")
   MessFile:close()
   
   local Inbound  = io.open([[\\sykplogiap01v\Version\LogiDataExe\Interfaces\PeopleSoft\inboundsettings.xml]])
   local InboundFileRead = Inbound:read("*all") 
   Inbound:close()
   
   local Msg = {}
   Msg = Load_Messages(xml.parse{data=MessFileRead})
   
   local Settings = {}
   Settings = Load_Messages(xml.parse{data=InboundFileRead}) 
   
   local Message_Dir     = Settings.MessageDir[1]..[[\]]
   local MessageFileName = 'ItemErrors'..iguana.id()..'.csv'
   
   if not conn or not conn:check() then
      
      conn = db.connect{
         api=db.SQL_SERVER,
         name='LogiData',
         user='logidata',
         password='logidata',
         use_unicode = true,
         live = true
      }
      
   end
   
   trace(Data)
   
   local QueryData = ''
   
   for i=1,#Data do


      local Status, Value = pcall(CheckNumber,Data[i])
      
      trace(Status, Value)
      
      if Status then
         QueryData = QueryData.."'"..(Value + 0).."'"
      end
      
      trace(i,#Data, i ~= #Data,Status)
      
      if i ~= #Data and Status then
         QueryData = QueryData..","
      end
      
   end

   trace(QueryData)

   if not conn:check() then
      iguana.logInfo('Database is not available.  Please retry updated')
      resubmit.resubmit{user='admin',password='L0g1d246',url='http://localhost:6543/',
         refid=os.date('%Y%m%d-%H%M%S'),message='No DB connection',channel='Update Repl. Source Prod',live=true}
      return
   end
   
   local SQLUpdate = [[UPDATE Produit SET CodeSource = 'ST' ]]..
   [[ WHERE CodeProduit IN (]]..QueryData..[[)]]..
   [[ AND CodeSource != 'ST' AND CodeSource != 'OV']]
   
   local Status, Errormsg = pcall(SQLExecute,conn,SQLUpdate)
   
   trace(Status,Errormsg)
   
   if not Status then
      if Errormsg == nil or Errormsg == '' then
         Errormsg = 'Pcall function returned nothing!'
      end
      --iguana.logInfo(Errormsg)
      CloseDatabaseHandling("Error during Update for the Stock Source in Produit.  SQL error: "..Errormsg,conn)
      return
   end
   
   local SQLUpdate = [[UPDATE Produit SET CodeSource = 'NS' ]]..
   [[FROM Produit P ]]..
   [[JOIN SourceApprovisionnement SA ON SA.CodeSource = P.CodeSource ]]..
   [[WHERE P.CodeProduit NOT IN(]]..QueryData..[[)]]..
   [[ AND P.CodeSource != 'NS' AND P.CodeSource != 'OV' AND SA.ReapproparDoubleCasier = 1 ]]
   
   trace(SQLQuery)
   
   local Status, Errormsg = pcall(SQLExecute,conn,SQLUpdate)
   
   if not Status then
      if Errormsg == nil or Errormsg == '' then
         Errormsg = 'Pcall function returned nothing!'
      end
      --iguana.logInfo(Errormsg)
      CloseDatabaseHandling("Error during Update for the Non-Stock Source in Produit.  SQL error: "..Errormsg,conn)
      return
   end
   
   local SQLUpdateDeptLocal = [[UPDATE ProduitDeptLocal ]]..
   [[SET CodeSource = Produit.CodeSource ]]..
   [[FROM Produit ]]..
   [[WHERE ProduitDeptLocal.IDProduit = Produit.IDProduit ]]..
   [[and ProduitDeptLocal.CodeSource <> Produit.CodeSource AND ProduitDeptLocal.CodeSource != 'OV']]

   local Status, ErrorMsg = pcall(SQLExecute,conn,SQLUpdateDeptLocal)

   if not Status then
      if Errormsg == nil or Errormsg == '' then
         Errormsg = 'Pcall function returned nothing!'
      end
      --iguana.logInfo(Errormsg)
      CloseDatabaseHandling("Error during Update for Repl. Sources in ProduitDeptLocal.  SQL error: "..Errormsg,conn)
      return
   end

   local ReportingImport = ''

   Status, ResultQueryProduit = pcall(SQLQuery,conn,[[select DISTINCT(P.CodeProduit), P.Description from ProduitDansCasier PDC
      JOIN Produit P ON P.IDProduit = PDC.IDProduit where p.CodeSpecialite = '$N']])
   
   if Status then 
      
      if not ResultQueryProduit:isNull() then
         
         ReportingImport = ReportingImport..'\nMessage,Item with description\n'
         
         for i=1,#ResultQueryProduit do
            
            ReportingImport = ReportingImport..Msg.Missing_Specialty[1]..','..
            ResultQueryProduit[i].CodeProduit..' '..ResultQueryProduit[i].Description..'\n'
            
         end
         
      end
      
   end
      
   trace(ReportingImport)

   conn:close() 
   
   local SendEmail = false
   local Status, LogFile = pcall(io.open,Message_Dir..MessageFileName,'a+')
   
   if Status and  ReportingImport ~= '' then
   
      SendEmail = true
      LogFile:write(ReportingImport)
                    
   end
      
   trace(Status,LogFile ~= nil)
   
   if Status then
      
      if LogFile ~= nil then
         
         local LogSize = LogFile:seek('end')
         
         if LogSize ~= 0 and LogSize ~= nil then

            LogFile:seek('set')
            local LogEntries = LogFile:read('*all')
            LogFile:close()
         
            trace(SendEmail)
            
            if SendEmail then
               
               if not iguana.isTest() then
                  
                  local Status, Errmsg = pcall(sendemail,Message_Dir,MessageFileName)
                  trace(Status,Errmsg,Message_Dir,MessageFileName)
                  
                  if Status then
                     iguana.logInfo("Item Error report sent")
                  else
                     iguana.logInfo("***** WARNING ***** Item Error report not sent!")
                  end

               end
               
            end
            
            iguana.logInfo('ITEM ERRORS:'..LogEntries)
            
         else
            
            LogFile:close()
            
         end
         
      else
         
         LogFile:close()                  
         
      end
      
   else
      
      LogFile:close()
      
   end

   local Status, RemoveFile = pcall(os.remove,Message_Dir..MessageFileName) 
   
end 


function CheckNumber(Data)
local value = Data + 0
return value
end

function sendemail(Message_Dir,MessageFileName)

   trace(Message_Dir,MessageFileName)
   
   retry.call{func=mime.send,arg1={server=[[smtpgwint.nshs.edu]],                        
         username=[[]],password=[[]],
         from=[[logidalerts@nslij.com]],to={'DCastro@NSHS.edu','Phart2@NSHS.edu',
            'Bdejean@NSHS.edu','Jrudy@NSHS.edu','tcaputo@NSHS.edu','Pyacenda@NSHS.edu',
            'michael.mcmanus@logi-d.net'},
         header={['Subject']=[[NSLIJ Item Specialty Error Report for ]]..os.date("%x")},body=[[CSV file attached to email]], 
         use_ssl=[[try]],timeout=120,attachments={Message_Dir..MessageFileName}},
      retry=5,pause=30}
   
end