require('split')
require('stringfunctions')

function trace(a,b,c,d) return end
-- The main function is the first function called from Iguana.
-- The Data argument will contain the message to be processed.

function main(Data)

   local searchdir = [[\\n2k3wb972ftp01\ftproot\FTPPeopleSoft\Finance\prod\incoming\ftp\LogiD\]]
   --local searchdir = [[\\syktlogiap01v\VersionTest\PeopleSoft\Inbound\Processed\]]
   --local ftp = net.ftp.init{server='erptstbat01.erp.nshs.edu',username=[[merkur]],password='perot1'}

   --local RemoteDir = ftp:list{remote_path='/faxout'}   

   trace(RemoteDir)
   iguana.setTimeout(86400)
  
   counter = 1 
   existingFiles = {}

--   local directory = io.popen('dir '..searchdir..' /b')
   
--   if directory == nil then
--      return
--   end
   
   local Status, Result = pcall(io.popen,'dir '..searchdir..' /b')
   
   trace(Status,Result)
   
   if not Status then
      return
   end
   
   for Filename, FileInfo in os.fs.glob(searchdir..'\*.*') do
      
      trace(Filename, FileInfo)

      Filename = Filename:upper()
      
      if Filename:find('XML') then 
            
            existingFiles[counter] = Filename
            counter = counter + 1
            trace(existingFiles)
                  
      end
      
   end
   
--   local List = directory:read('*a') 
   
--   for key, filelist in pairs(List:split('\n')) do

--      trace(key, filelist.filename)
--      RemoteFile = filelist.filename
--      trace(RemoteFile)

--      if filelist:find('XML') then 
         
--         existingFiles[counter] = filelist
--         counter = counter + 1
--         trace(existingFiles)
         
--      end
      
--   end
   
   trace(existingFiles)


   for key, existingfile in pairs(existingFiles) do
      
      trace(existingfile)  
      --local XMLfile = ftp:get{remote_path='/faxout/'..existingfile}  
      local filename = io.open(existingfile) 
      
      if filename == nil then
         return
      end
      
      local XMLfile  = filename:read('*a')
      filename:close()

      --XMLparse = xml.parse("<ItemData><Vendor>0000000003</Vendor><Item>14749</Item><ItemStatus>1</ItemStatus>"..
       --  "<Description>SOL WSH 3</Description><VendorItemID>8A8104</VendorItemID><DistributionUnit>EA</DistributionUnit>"..
        -- "<BuyingUnit>EA</BuyingUnit><PkgQty>1</PkgQty><ProductValue>.01</ProductValue><Stock>N</Stock></ItemData>")
      
      XMLparse = xml.parse(XMLfile)
      
      for i=1,XMLparse.ZZ_PUSH_832_LOGI.MsgData.Transaction.ZZ_IN_ITEM_HDR:childCount("ZZ_IN_ITEM_SYNC") do

         XML = XMLparse.ZZ_PUSH_832_LOGI.MsgData.Transaction.ZZ_IN_ITEM_HDR:child("ZZ_IN_ITEM_SYNC",i)
         trace(XML)
         inventoryitem    = Check_ChildCount(XML.INV_ITEM_ID)
         itemstatus       = Check_ChildCount(XML.ITM_STATUS_CURRENT)
         conversionrate   = Check_ChildCount(XML.CONVERSION_RATE)
         pricelist        = Check_ChildCount(XML.PRICE_LIST)
         distributionunit = Check_ChildCount(XML.UNIT_MEASURE_STD)
         orderunit        = Check_ChildCount(XML.UNIT_OF_MEASURE)
         vendoritemid     = Check_ChildCount(XML.MFG_ITM_ID)
         description      = Check_ChildCount(XML.DESCR60)
         vendorid         = Check_ChildCount(XML.VENDOR_ID)
         Stockflag        = Check_ChildCount(XML.ZZ_STOCK_FLG)
         
         --description      = Escape_Characters(XML.DESCR60[2]:nodeValue())
         --vendorid      = Escape_Characters(XML.VENDOR_ID[1]:nodeValue())
         trace(conversionrate,pricelist)
         
         -- Remove leading zeros from Item_ID
         inventoryitem = inventoryitem + 0
         trace(inventoryitem)
         
         --trace(MySQLEscape(TestXML.DESCR60[2]))
         --local jsonextract = '[{"Vendor":"'..TestXML.VENDOR_ID[2]..'","Item":"'..TestXML.INV_ITEM_ID[2]..'",'..
         --'"ItemStatus":"'..TestXML.ITM_STATUS_CURRENT[2]..'","Description":"'..TestXML.DESCR60[2]..'",'..
         --'"VendorID":"'..TestXML.MFG_ITM_ID[2]..'","UnitOfMeasureStd":"'..TestXML.UNIT_MEASURE_STD[2]..'",'..
         --'"UnitOfMeasure":"'..TestXML.UNIT_OF_MEASURE[2]..'","ConversionRate":"'..conversionrate..
         --'","Price":"'..TestXML.PRICE_LIST[2]..'","StockYN":"'..TestXML.ZZ_STOCK_FLG[2]..'","OrderBy":"'..
         --TestXML.ZZ_ORDER_BY[2]..'"}]'
         --trace(jsonextract)ue()
         --XML.ZZ_STOCK_FLG[2]:nodeValue()
         --TestXML.PRICE_LIST[2]:nodeValue()
         local xmlextract = "<ItemData><Vendor>"..vendorid.."</Vendor><Item>"..inventoryitem..
         "</Item><ItemStatus>"..itemstatus.."</ItemStatus><Description>"..description..
         "</Description><VendorItemID>"..vendoritemid.."</VendorItemID><DistributionUnit>"..distributionunit..
         "</DistributionUnit><BuyingUnit>"..orderunit.."</BuyingUnit><PkgQty>"..conversionrate..
         "</PkgQty><ProductValue>"..pricelist.."</ProductValue><Stock>"..Stockflag..
         "</Stock></ItemData>"
         trace(xmlextract)
         queue.push{data=xmlextract}
                  
      end
      
      if not iguana.isTest() then

         Handle_File(existingfile)
         --local Result, test = os.rename(searchdir..existingfile,[[\\syktlogiap01v\VersionTest\PeopleSoft\Inbound\Processed\]]..os.date("%Y%m%d")..[[\]]..existingfile)
         --local Result, test = os.rename([[\\syktlogiap01v\VersionTest\PeopleSoft\Inbound\Processed\]]..existingfile,
         --[[\\syktlogiap01v\VersionTest\PeopleSoft\Inbound\Processed\]]--..os.date("%Y%m%d")..[[\]]..existingfile) 
         --trace(Result,test)
         --ftp:get{remote_path='/faxout/'..existingfile,local_path=[[\\syktlogiap01v\VersionTest\PeopleSoft\Inbound\Processed\]]..
         --   os.date("%Y%m%d")..[[\]]..existingfile,overwrite=true}
         --ftp:delete{remote_path='/faxout/'..existingfile}
         
      end
      
   end
   
   trace(newfilename,extension)

end

function Check_ChildCount(Node)
   
   --trace(Node:childCount())
   
   if Node:childCount() == 0 then
      return ''
   end
   
   if Node:childCount() >= 2 then
      return Escape_Characters(Node[2]:nodeValue())
   else
      return Escape_Characters(Node[1]:nodeValue())
   end
      
end

function Escape_Characters(xmlelement)
   
   xmlelement = xmlelement:gsub(">","&gt;")
   xmlelement = xmlelement:gsub("<","&lt;")
   xmlelement = xmlelement:gsub("&","&amp;")
   xmlelement = xmlelement:gsub('"',"&quot;")
   xmlelement = xmlelement:gsub("'","&apos;")

   return xmlelement
   
end


function Handle_File(filetomove)

   local MovetoDir = [[\\sykplogiap01v\Version\PeopleSoft\Inbound\Processed\]]..os.date("%Y%m%d")..[[\]]
   local movefile  = [[ProcessedIM]]..os.date("%Y%m%d")..[[-]]..os.date("%H%M")

   local Checkdir, Err  = pcall(os.fs.mkdir,MovetoDir)
      
   trace(Checkdir,Err)

--   local directory = io.popen('dir '..MovetoDir..' /b')
--   local List = directory:read('*a')
   
--   trace(List)
  
   counter = 1 
   existingFiles = {}
   
   for Filename, FileInfo in os.fs.glob(MovetoDir..'\*.*') do

--   for key, filelist in pairs(List:split('\n')) do

      trace(key, filelist)
      --RemoteFile = string.upper(filelist)
      trace(RemoteFile)
      
      --TestValue = RemoteFile:find(".",1,plain)


      if Filename:find('ProcessedIM') then
         
         existingFiles[counter] = Filename
         counter = counter + 1
         trace(existingFiles)
         
      end
      
   end
   
   extension = '001'
   newfilename = movefile..[[-]]..extension..[[.XML]]
   trace(newfilename)
   
   FileFound = true
   
   while FileFound do
   
      FileFound = false
      
      for i=1,#existingFiles do
      
         newfilename = movefile..[[-]]..extension..[[.XML]]
         --newfilename = 'LOGID_RQ_'..extension..'.xml'
            
         trace(existingFiles[i]:upper(), newfilename:upper())
      
         if existingFiles[i]:upper() == newfilename:upper() then
         
            extension = string.format("%03d",extension+1)
            FileFound = true

         end
      
      end

   end   

   trace(movefile,newfilename)
   
   if not iguana.isTest() then
      local Result, test = os.rename(filetomove,MovetoDir..newfilename)
      
      if Result == nil then
         os.remove(filetomove)
      end
      
   end
   
end