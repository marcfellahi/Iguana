require ('dbc') 
require ('files') 
require ('throttled')
 
function trace(a,b,c,d) return end

-- Directory waiting for incoming messages 
-- <iguana install>\<INPUT_DIR>
INPUT_DIR = [[\\n2k3wb972ftp01\ftproot\FTPPeopleSoft\Finance\prod\incoming\ftp\LogiD]]
-- Where to put files after processing 
ARCHIVED_DIR = [[\\sykplogiap01v\Version\PeopleSoft\Inbound\Processed]]
-- file name/pattern to look for
FILE_PATTERN = '*.CSV' 

-- check  incoming directory convert xls to CSV
-- parse CSV files, move files to processed directory
function main ()
   
   local hours = os.date('%H') + 0
   local mins  = os.date('%M') + 0

   if hours < 19 or hours > 19 then
      return nil
   end
   
   if not iguana.isTest() then
      
      --local DirectoryFiles = files.dir(INPUT_DIR,FILE_PATTERN) 
      
      --iguana.logInfo(DirectoryFiles)
      
      --if DirectoryFiles == nil then
      --   return
      --end
      
      for FileName, FileInfo in os.fs.glob(INPUT_DIR..[[\]]..FILE_PATTERN) do
      -- Find the oldest file (not a directory)
      --for key, name in pairs (DirectoryFiles) do 
         --local FileName=INPUT_DIR..[[\]]..name
         
         trace(FileName,FileInfo)
         
         local File=io.open(FileName) 
         if (File) then 
            -- Not a directory 
            local Data=File:read("*all")
            Data=FileName..'\n'..Data
            queue.push{data=Data}
            io.close(File) 
            -- testing
            --local f=io.open(INPUT_DIR..'\\TestOut.txt', 'w')
            --f:write(S)
            --f:close()
            ---------
            trace(FileName)
            
            --iguana.logInfo("Processed Files!")
            
            if not iguana.isTest() then 
               HandleFiles(FileName)
            end 
            
         end 
      end 
      
   end
   
end

function HandleFiles(FileName)
   

   local MovetoDir  = [[\\sykplogiap01v\Version\PeopleSoft\Inbound\Processed\]]..os.date("%Y%m%d")
   local movefile   = [[ProcessedSourceUpdate]]..os.date("%Y%m%d")..[[-]]..os.date("%H%M")
   local Checkdir, Err  = pcall(os.fs.mkdir,MovetoDir)
      
   trace(Checkdir,Err)

   local directory = io.popen('dir '..MovetoDir..' /b')
   local List = directory:read('*a')
   
   trace(List)
  
   counter = 1 
   existingFiles = {}
   
   for key, filelist in pairs(List:split('\n')) do

      trace(key, filelist)
      --RemoteFile = string.upper(filelist)
      trace(RemoteFile)
      
      --TestValue = RemoteFile:find(".",1,plain)


      if filelist:find('ProcessedSourceUpdate') then
         
         existingFiles[counter] = filelist
         counter = counter + 1
         trace(existingFiles)
         
      end
      
   end
   
   extension = '001'
   newfilename = movefile..[[-]]..extension..[[.CSV]]
   trace(newfilename)
   
   FileFound = true
   
   while FileFound do
   
      FileFound = false
      
      for i=1,#existingFiles do
      
         newfilename = movefile..[[-]]..extension..[[.CSV]]
         --newfilename = 'LOGID_RQ_'..extension..'.xml'
            
         trace(existingFiles[i]:upper(), newfilename:upper())
      
         if existingFiles[i]:upper() == newfilename:upper() then
         
            extension = string.format("%03d",extension+1)
            FileFound = true

         end
      
      end

   end   

   trace(movefile,newfilename)
   
   if not iguana.isTest() then
      
      local Result, test = os.rename(FileName,MovetoDir..[[\]]..newfilename)
      
      if Result == nil then
         os.remove(filetomove)
      end
   
   end
   
   
   
end