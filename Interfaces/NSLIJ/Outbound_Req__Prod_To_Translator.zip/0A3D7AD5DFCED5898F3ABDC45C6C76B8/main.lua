require('stringutils')

function trace(a,b,c,d) return end
-- The main function is the first function called from Iguana.
-- The Data argument will contain the message to be processed.

local OutFixedValues = [[\\sykplogiap01v\Version\LogiDataExe\Interfaces\PeopleSoft\OutBoundFixedValues.xml]]
local OutHeader      = [[\\sykplogiap01v\Version\LogiDataExe\Interfaces\PeopleSoft\OutBoundHeader.txt]]
local OutTrailer     = [[\\sykplogiap01v\Version\LogiDataExe\Interfaces\PeopleSoft\OutBoundTrailer.txt]]


function readfile(Fixefile)
   
   return Fixefile:read("*a")
   
end

function main(Data)
  
   local searchdir = [[\\n2k3wb972ftp01\ftproot\FTPPeopleSoft\Finance\prod\outgoing\ftp\LogiD]]
   trace(Data)
 
   local FixedFile = io.open(OutFixedValues,"r") 
   trace(FixedFile)
   local FixedValues = xml.parse{data=FixedFile:read("*a")}
   FixedFile:close()
   trace(FixedValues)

   local HeaderFile  = io.open(OutHeader,"r")
   local Header = HeaderFile:read("*a")
   HeaderFile:close()
   trace(Header)

   local TrailerFile = io.open(OutTrailer,"r")
   local Trailer = TrailerFile:read("*a")
   TrailerFile:close()
   trace(Trailer)
   
   trace(Data)

   Data = Escape_JsonData(Data,1)
   trace(Data)
   
   local jsonextract = json.parse{data=Data}

   trace(#jsonextract)
   
   data = Header
   trace(data)
   
   data = data..BuildSegments(jsonextract,FixedValues)
   
   data = data..Trailer
   
   trace(data)
   
   --local ftp = net.ftp.init{server='erptstbat01.erp.nshs.edu',username=[[merkur]],password='perot1',live=true}

   --local RemoteDir = ftp:list{remote_path='/'}   

   local directory = io.popen('dir '..searchdir..' /b')
   local List = directory:read('*a')
   
   trace(List)
  
   counter = 1 
   existingFiles = {}
   
   for key, filelist in pairs(List:split('\n')) do

      trace(key, filelist)
      --RemoteFile = string.upper(filelist)
      trace(RemoteFile)
      
      --TestValue = RemoteFile:find(".",1,plain)


      if filelist:find('LOGID_RQ') then
         
         existingFiles[counter] = filelist
         counter = counter + 1
         trace(existingFiles)
         
      end
      
   end
   
   trace(existingFiles)

   extension = '001'
   currentdate = os.date("%m%d%Y%H%M%S")
   newfilename = 'LOGID_RQ_'..currentdate..'_'..extension..'.xml'
   --newfilename = 'LOGID_RQ_'..extension..'.xml'
   trace(newfilename)
   
   FileFound = true
   
   while FileFound do
   
      FileFound = false
      
      for i=1,#existingFiles do
      
         newfilename = 'LOGID_RQ_'..currentdate..'_'..extension..'.xml'
         --newfilename = 'LOGID_RQ_'..extension..'.xml'
            
         trace(existingFiles[i]:upper(), newfilename:upper())
      
         if existingFiles[i]:upper() == newfilename:upper() then
         
            extension = string.format("%03d",extension+1)
            FileFound = true

         end      
      
      end

   end
   
   trace(newfilename,extension)

   if not iguana.isTest() then

      local filename = searchdir..[[\]]..newfilename
      local f = io.open(filename,"wb")      
      f:write(data)
      f:close()
      --ftp:put{remote_path='/'..newfilename,data=data,debug=true}
      
   end
   
end

function BuildSegments(jsondata,values)

local transactions = ''

   for i=1,#jsondata do
      
      trace(jsondata[i].Product,jsondata[i].Description,jsondata[i].Serial,jsondata[i].Lot)
      trace(jsondata,jsondata[i].QuantityOrder)
      
      if jsondata[i].Serial ~= '' and jsondata[i].Serial ~= nil then
         jsondata[i].Description = 'SERIAL# '..jsondata[i].Serial
      else
         if jsondata[i].Lot ~= '' and jsondata[i].Serial ~= nil  then
            jsondata[i].Description = 'LOT# '..jsondatadatadata[i].Lot
         end
      end
      
      trace(jsondata[i].QuantityOrder)
      
      -- Pad zeroes in front of product number
      jsondata[i].Product = string.format("%018s",jsondata[i].Product)
      
      trace(jsondata[i].Description, jsondata[i].Product,jsondata[i].QuantityOrder)
      
      transactions = transactions..'<Transaction>\n'..'<PO_REQLOAD_SEG class="R">'..
      '<LOADER_BU IsChanged="Y">'..values.Fixed_Values.BusinessUnit[1]..'</LOADER_BU>\n'..
      '<GROUP_SEQ_NUM>0</GROUP_SEQ_NUM>\n'..
      '<REQUESTOR_ID IsChanged="Y">'..jsondata[i].RequestorId..'</REQUESTOR_ID>\n'..
      '<EMAILID/>\n'..
      '<DUE_DT/>\n'..
      '<INV_ITEM_ID IsChanged="Y">'..jsondata[i].Product..'</INV_ITEM_ID>\n'..
      '<DESCR254_MIXED IsChanged="Y">'..jsondata[i].Description..'</DESCR254_MIXED>\n'..
      '<UNIT_OF_MEASURE IsChanged="Y">'..jsondata[i].UOM..'</UNIT_OF_MEASURE>\n'..
      '<QTY_REQ IsChanged="Y">'..jsondata[i].QuantityOrder..'</QTY_REQ>\n'..
      '<PRICE_REQ/>\n'..
      '<CURRENCY_CD/>\n'..
      '<VENDOR_ID/>\n'..
      '<LOCATION/>\n'..
      '<CATEGORY_ID/> \n'..
      '<SHIPTO_ID/> \n'..
      '<REQ_ID/> \n'..
      '<LINE_NBR>0</LINE_NBR> \n'..
      '<ACCOUNT/> \n'..
      '<ALTACCT/> \n'..
      '<DEPTID/> \n'..
      '<OPERATING_UNIT/> \n'..
      '<PRODUCT/>\n'..
      '<FUND_CODE/>\n'..
      '<CLASS_FLD/>\n'..
      '<PROGRAM_CODE/>\n'..
      '<BUDGET_REF/> \n'..
      '<AFFILIATE/> \n'..
      '<AFFILIATE_INTRA1/> \n'..
      '<AFFILIATE_INTRA2/> \n'..
      '<CHARTFIELD1/> \n'..
      '<CHARTFIELD2/> \n'..
      '<CHARTFIELD3/> \n'..
      '<PROJECT_ID/> \n'..
      '<BUSINESS_UNIT_IN/>\n'.. 
      '<BUSINESS_UNIT_PC/> \n'..
      '<ACTIVITY_ID/> \n'..
      '<RESOURCE_TYPE/> \n'..
      '<RESOURCE_CATEGORY/> \n'..
      '<RESOURCE_SUB_CAT/> \n'..
      '<ANALYSIS_TYPE/> \n'..
      '<BUSINESS_UNIT_GL/> \n'..
      '<CALC_PRICE_FLG/> \n'..
      '<BUSINESS_UNIT_AM/> \n'..
      '<PROFILE_ID/> \n'..
      '<TAG_NUMBER/> \n'..
      '<CAP_NUM/> \n'..
      '<CAP_SEQUENCE>0</CAP_SEQUENCE> \n'..
      '<EMPLID/> \n'..
      '<FINANCIAL_ASSET_SW/> \n'..
      '<COST_TYPE/> \n'..
      '<ULTIMATE_USE_CD/>\n'.. 
      '<REVISION/> \n'..
      '<ENTRY_EVENT/> \n'..
      '<USER_HDR_CHAR1/> \n'..
      '<USER_LINE_CHAR1/> \n'..
      '<USER_SCHED_CHAR1/> \n'..
      '<USER_DIST_CHAR1/> \n'..
      '<PO_RQLD_CMT_SEG class="R">\n'..
      '<LOADER_BU IsChanged="Y">'..values.Fixed_Values.BusinessUnit[1]..'</LOADER_BU>\n'..
      '<GROUP_SEQ_NUM>0</GROUP_SEQ_NUM>\n'..
      '<COMMENT_SEQ>0</COMMENT_SEQ>\n'..
      '<COMMENT_REQ_TYPE IsChanged="Y">'..values.Fixed_Values.CommentReqType[1]..'</COMMENT_REQ_TYPE>\n'..
      '<DESCR254 IsChanged="Y">'..jsondata[i].Description..'</DESCR254>\n'..
      '<PUBLIC_FLG/>  \n'..
      '<ALLOW_MODIFY/>  \n'..
      '<RECV_VIEW_FLG/>  \n'..
      '<VCHR_VIEW_FLG/>  \n'..
      '</PO_RQLD_CMT_SEG>  \n'..
      '</PO_REQLOAD_SEG> \n'..
      '<PSCAMA class="R">  \n'..
      '<LANGUAGE_CD>ENG</LANGUAGE_CD>  \n'..
      '<AUDIT_ACTN/>  \n'..
      '<BASE_LANGUAGE_CD>ENG</BASE_LANGUAGE_CD>  \n'..
      '<MSG_SEQ_FLG/>  \n'..
      '<PROCESS_INSTANCE>0</PROCESS_INSTANCE>  \n'..
      '<PUBLISH_RULE_ID/>  \n'..
      '<MSGNODENAME/>  \n'..
      '</PSCAMA>  \n'..
      '</Transaction>  \n'
      
      trace(transactions)
               
   end
   
   return transactions
      
end

function Escape_JsonData(data,startstring)
   
   local begextract  = 0
   local endextract = 0
   trace(data)
   
   trace(startstring,endextract)
   
   if data:find('":',startstring) == nil then
      return data
   else
   
      begextract = data:find('":',startstring)
      lastextract = data:find("},",begextract)
      trace(begextract,lastextract)
      
      if data:find(',"',data:find('":',startstring)+2) ~= nil then

         endextract = data:find(',"',data:find('":',startstring)+3)-1
         trace(begextract,lastextract,endextract,endextract2)
         
         if endextract > lastextract then
            endextract = lastextract-1
         end

      else
         
         endextract = lastextract-1
         
      end

      trace(data,begextract,endextract,lastextract-1)
      extractfirstpart = data:sub(1,begextract+2)
      datasubbed = data:sub(begextract+3,endextract-1)
      trace(datasubbed)
      escapedata       = Replace_characters(datasubbed)
      extractlastpart = data:sub(endextract)
   
      trace(escapedata)
      
      data = extractfirstpart..escapedata..extractlastpart
      
      trace(extractfirstpart,extractlastpart)
      trace(data)
      
      return Escape_JsonData(data,endextract+1)
      
   end
   
end

function Replace_characters(escapeddata)
   
   escapeddata = escapeddata:gsub(">","&gt;")
   escapeddata = escapeddata:gsub("<","&lt;")
   escapeddata = escapeddata:gsub("&","&amp;")
   escapeddata = escapeddata:gsub('"',"&quot;")
   escapeddata = escapeddata:gsub("'","&apos;")
   
   return escapeddata
   
end