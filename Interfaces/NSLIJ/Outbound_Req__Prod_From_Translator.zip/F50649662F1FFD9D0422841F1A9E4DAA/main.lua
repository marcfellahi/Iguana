require('filehandling')
require('LdIguanaFileLibrary')
require('stringutils')

local function trace(a,b,c,d) return end

local incomingfile       = "LOGID_RQ"
local sourcedirectory    = [[\\sykplogiap01v\Version\LogiDataRE\]]

trace(sourcedirectory)

function main()
   
   local data
   local filenames = scandir(sourcedirectory, incomingfile)

   if filenames ~= nil then
   
      for i=1,#filenames do
             
         local filetobeprocessed = filenames[i]

         data = ProcessFile(sourcedirectory, filetobeprocessed)
         trace(data)
         
         if not iguana.isTest() then
            
            --iguana.logInfo(data)
            queue.push{data=data}

            os.remove(sourcedirectory..filenames[i])            
            
         end

      end

   end
   
end


function ProcessFile(directory, file)

   local data           = ''
   local fileandpath    = directory..file
   
   local Status, fileopen = pcall(io.open,fileandpath, "r")

   trace(fileandpath, Status, fileopen)
            
   if fileopen ~= nil then
      
      for line in fileopen:lines() do

          trace(line)
          data = data..line
         
      end
      
      trace(data)
      io.close(fileopen)
      
   end
   
   --print('complete segment: ',data)

   return data

end

function scandir(directory, fileext)
   
   local counter = 1
   local nameindex = {}
   
   
   local filenames = io.popen('dir /b '..directory)
   trace(filenames)
   
   if filenames == nil then
      return nil
   end
   
   local list      = filenames:read('*a')
   
   for k,v in pairs(list:split('\n')) do

      local listname = v:upper() 
      
      if listname:find(fileext) ~= nil then
      
         nameindex[counter] = v
         counter = counter + 1

      end
      
   end
   
   filenames:close()
   
   trace(nameindex)
      
   return nameindex
   
end   