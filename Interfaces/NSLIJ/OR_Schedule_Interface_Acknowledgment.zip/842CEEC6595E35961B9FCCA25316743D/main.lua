require('node')
require('split')
require('stringutil')

function trace(a,b,c,d) return end

-- The main function is the first function called from Iguana.
-- The Data argument will contain the message to be processed.
function main(Data)

   local EscapeData = Data:split('\r')
   
   DataEsc = ''
   
   for i=1,#EscapeData do
   
      if EscapeData[i]:sub(1,3) ~= 'MSH' then
         EscapeData[i] = Escape_Characters(EscapeData[i])
      end
      DataEsc = DataEsc..EscapeData[i]..'\r'
      
   end

   local inboundvmd = 'HL7_OR_Schedule_Inbound.vmd'
   
   local validated, HL7result = pcall(ValidateHL7,inboundvmd,DataEsc)
   trace(validated, HL7result)
   
   if validated then

      HL7data, MsgName, Warnings = hl7.parse{vmd='HL7_OR_Schedule_Inbound.vmd',data=Data}
      HL7ack, AckName, AckWarnings = hl7.parse{vmd='ack.vmd',data=Data}
      
      HL7message = hl7.message{vmd='ack.vmd',name='Ack'}
      
      --Prepare_Ack(HL7data,HL7message)
      --trace(HL7message)
      
      if Warnings ~= nil then
         for i,Warning in ipairs(Warnings) do
            trace(Warning)
            local acksend = Return_NACK(HL7data,HL7message,Warning.description)
            ack.send(acksend:S())
            return
         end
      end
      
   else
   
      --iguana.logInfo(Data)
      local HL7data = hl7.parse{vmd='ack.vmd',data=[[MSH|^~\&|SIS|FHMC-OR|null|null|20130904144329|||1102|T|2.4||||||]]}
      local nackmessage = hl7.message{vmd='ack.vmd',name='Ack'}
      local acksend = Return_NACK(HL7data,nackmessage,'This is not an HL7 message.  Message rejected.')
      ack.send(acksend:S())
      return
      
   end   
  
   acksend = Prepare_Ack(HL7data,HL7message)   
   ack.send(acksend:S())
   return
   
end



function Convert_DatetoDatetime(Date)
   
   local dateyear = Date:sub(1,4)
   local datemth  = Date:sub(5,6)
   local dateday  = Date:sub(7,8)
   local datehour = Date:sub(9,10)
   local datemin  = Date:sub(11,12)
   local datesec  = Date:sub(13,14)
   
   return (dateyear..'-'..datemth..'-'..dateday..' '..datehour..':'..datemin..':'..datesec)
   
end


function Escape_Characters(element)
   
   --element = element:gsub("&","\\T\\")

   return element
   
end

function POSTMessage(call,jsondata)
   
   return net.http.post{url='http://SYKTLOGIAP01V:82/import/'..call,
         --url="http://SVR-BEAMAX02:82/Import/"..functioncall,
         headers={'Content-Type:application/json','charset:utf-8'}, body=jsondata,live=true}
   
end

function ParseResults(resultsdata)
   
   local returnresult = json.parse{data=resultsdata} 
   
end

function Prepare_Ack(Msg,Ack)
   
   --Ack.MSH[3][1] = Msg.MSH[5][1]
   --Ack.MSH[4][1] = Msg.MSH[6][1]
   Ack.MSH[3][1] = 'CIRCUIT-iD ORS'
   Ack.MSH[4][1] = 'LOGID'
   Ack.MSH[5][1] = Msg.MSH[3][1]
   Ack.MSH[6][1] = Msg.MSH[4][1]
   Ack.MSH[10] = Msg.MSH[10]
   Ack.MSH[9][1] = 'ACK'
   Ack.MSH[11][1] = 'P'
   Ack.MSH[12][1] = '2.6.1'
   Ack.MSH[7][1] = os.date('%Y%m%d%H%M%S')
   
   Ack.MSA[1] = 'AA'
   Ack.MSA[2] = Msg.MSH[10]
   Ack.MSA[3] = 'Success'
   
   return Ack
   
end


function Return_NACK(Msg,Ack,Reason)

   Ack.MSH[3][1] = 'CIRCUIT-iD ORS'
   Ack.MSH[4][1] = 'LOGID'
   Ack.MSH[5][1] = Msg.MSH[3][1]
   Ack.MSH[6][1] = Msg.MSH[4][1]
   Ack.MSH[10] = Msg.MSH[10]
   Ack.MSH[9][1] = 'ACK'
   Ack.MSH[11][1] = Msg.MSH[11][1]
   Ack.MSH[12][1] = Msg.MSH[12][1]
   Ack.MSH[7][1] = os.date('%Y%m%d%H%M%S')
   
   Ack.MSA[1] = 'AE'
   Ack.MSA[2] = '1102'
   Ack.MSA[3] = Reason

   return Ack
   
end


function SendJsonData(data, event)
   
   trace(data,event)
   
   if event == 'S12' or event == 'S13' or event == 'S14' then
      functioncall = 'CreateOrUpdateCase'
      iguana.logInfo('Create or Update Case')
   else
      functioncall = 'DeleteCase'
      iguana.logInfo('Delete Case')
   end
   
   local jsontransmit = json.serialize{data=data}
   
   if not iguana.isTest() then

      Status, Results = pcall(POSTMessage,functioncall,jsontransmit)      
      trace(Results)
      
   end

   if not Status then
      Results = '{"Result":false,"Message":"Unknown error.  Please contact IT support."}'
   end
   
   return Results
   
end

function ValidateHL7(vmdfile, data)
   
   return hl7.parse{vmd=vmdfile,data=data}
   
end

