require('node')
require('split')
require('stringutil')

function trace(a,b,c,d) return end

-- The main function is the first function called from Iguana.
-- The Data argument will contain the message to be processed.
function main(Data)

   HL7data = hl7.parse{vmd='HL7_OR_Schedule_Inbound.vmd',data=Data}

   trace(HL7data)
   
   local eventtype = HL7data.MSH[9][2]:nodeValue()

   local CaseId           = HL7data.PV1[19]:nodeValue()
   local StartDate        = HL7data.SCH[11][1][4]:nodeValue()
   local DepartmentId     = HL7data.AIL[4][1]:nodeValue()
   local RoomId           = HL7data.AIL[3][1][2][1]:nodeValue():trimWS()
   local PatientID        = HL7data.PID[3][1][1]:nodeValue()
   local PatientFirstName = HL7data.PID[5][1][2]:nodeValue()
   local PatientLastName  = HL7data.PID[5][1][1][1]:nodeValue()
   local SurgeonId        = HL7data.SCH[12][1][1]:nodeValue()
   local SurgeonFirstName = HL7data.SCH[12][1][3]:nodeValue()
   local SurgeonLastName  = HL7data.SCH[12][1][2][1]:nodeValue()

   local ProcedureCode = {}
   local ProcedureName = {}
   
   trace(HL7data.AISNTE)

   for i=1,HL7data.AISNTE:childCount() do
 
      if HL7data.AISNTE[i].AIS[1]:nodeName():upper() == 'SET ID - AIS' then
         ProcedureCode[i] = HL7data.AISNTE[i].AIS[3][1]:nodeValue()
         ProcedureName[i] = HL7data.AISNTE[i].AIS[3][2]:nodeValue()
      else
         ProcedureCode[i] = HL7data.AISNTE[i].AIS[1][3][1]:nodeValue()   
         ProcedureName[i] = HL7data.AISNTE[i].AIS[1][3][2]:nodeValue()
      end
      
   end
   
   StartDate = Convert_DatetoDatetime(StartDate)
   
   local jsondata = ''
   
   if eventtype == 'S12' or eventtype == 'S13' or eventtype == 'S14' then
      
      jsondata = '{"Code":"'..CaseId..'","ScheduledOn":"'..StartDate..'","Room":"'..
      RoomId..'","Department":"'..DepartmentId..'","PatientID":"'..PatientID..'","PatientLastName":"'..
      PatientLastName..'","PatientFirstName":"'..PatientFirstName..'","Procedures":['
   
      for i=1,#ProcedureCode do
         
         jsondata = jsondata..
         '{"Surgeon":{"SurgeonCode":"'..SurgeonId..'","FirstName":"'..SurgeonFirstName..
         '","LastName":"'..SurgeonLastName..'"},'..
         '"Procedure":{"Code":"'..ProcedureCode[i]..'","Name":"'..ProcedureName[i]..'"}},'
                  
      end
      
      jsondata = jsondata..']}'

   else 
      
      if eventtype == 'S15' then
         
         jsondata = '{"Code":"'..CaseId..'"}'
         
      end
         
   end
   
   jsonparsed = json.parse{data=jsondata}
   
   
   trace(jsondata)
   
   local Results = SendJsonData(jsonparsed, eventtype)
   
   Status, Resultsparsed = pcall(json.parse,Results)
   
   if Status then
      if Resultsparsed.Result then        
         
         if eventtype == 'S12' or eventtype == 'S13' or eventtype == 'S14' then
            iguana.logInfo('SUCCESS: Case '..jsonparsed.Code..' added/updated.')
         else 
            iguana.logInfo('SUCCESS: Case '..jsonparsed.Code..' deleted.')
         end
         
      else
         -- Fix put in place to address a case being changed from a room that exists to
         -- a room that does not exist.  It would normally disregard and keep it in the
         -- old room.  As a short-term measure, we now capture if it was rejected because
         -- of a wrong room.  If the case already existed, we request the service to
         -- delete the case to take it off the grid.
         -- Marc Fellahi  2013/12/13  10:19
         --if Resultsparsed.Message:find('No room was found') ~= nil then
         
         --   if not conn or not conn:check() then
         
         --     conn = db.connect{
         --         api=db.SQL_SERVER,
         --         name='LogiData',
         --         user='logidata',
         --         password='logidata',
         --         use_unicode = true,
         --        live = true
         --      }
         
         --   end
         
         --   trace(conn)
         
         --   local resultSQL = conn:query{sql="SELECT * FROM logidata.Operations WHERE OperationCode = '"..jsonparsed.Code.."'"}
         
         --   trace(resultSQL)
         
         --   conn:close()
         
         --   if not resultSQL[1].OperationCode:isNull() then
         
         --      jsondata = '{"Code":"'..CaseId..'"}'
         
         --      jsonparsed = json.parse{data=jsondata}
         --      local Results = SendJsonData(jsonparsed, 'S15')
         
         --      Status, Resultsparsed = pcall(json.parse,Results)
         
         --      if Status then
         --         iguana.logInfo('SUCCESS: Case '..jsonparsed.Code..' deleted.')                  
         --      else
         --         iguana.logInfo('ERROR: '..Resultsparsed.Message)                  
         --      end
         --   else
         --      iguana.logInfo('ERROR: '..Resultsparsed.Message)
         --   end
         
         --else
         
         --  iguana.logInfo('ERROR: '..Resultsparsed.Message)
         
         --end      
         if Resultsparsed.Message:find('No room was found') ~= nil then
            
            if not conn or not conn:check() then
               
               conn = db.connect{
                  api=db.SQL_SERVER,
                  name='LogiData',
                  user='logidata',
                  password='logidata',
                  use_unicode = true,
                  live = true
               }
               
            end
            
            trace(conn)
            
            local resultSQL = conn:query{sql="SELECT * FROM logidata.Operations WHERE OperationCode = '"..jsonparsed.Code.."'"}
            
            trace(resultSQL)
            
            if not resultSQL[1].OperationCode:isNull() then
               
               local resultSQL = conn:execute{sql="UPDATE logidata.Operations SET Status = 5 WHERE OperationCode = '"..jsonparsed.Code.."'"}
               
               trace(resultSQL)
               
               --jsondata = '{"Code":"'..CaseId..'"}'
               
               --jsonparsed = json.parse{data=jsondata}
               --local Results = SendJsonData(jsonparsed, 'S15')
               
               --Status, Resultsparsed = pcall(json.parse,Results)
               
               --if Status then
               iguana.logInfo('OR CASE IMPORT SUCCESS: Case '..jsonparsed.Code..' deleted.')                  
               --else
               --   iguana.logInfo('ERROR: '..Resultsparsed.Message)                  
               --end
               
            else
               iguana.logInfo('OR CASE IMPORT ERROR: '..Resultsparsed.Message)                   
            end
            
            conn:close()            
            
         else
            
            iguana.logInfo('OR CASE IMPORT ERROR: '..Resultsparsed.Message)
            
         end  
      end
   end      
   
end



function Convert_DatetoDatetime(Date)
   
   local dateyear = Date:sub(1,4)
   local datemth  = Date:sub(5,6)
   local dateday  = Date:sub(7,8)
   local datehour = Date:sub(9,10)
   local datemin  = Date:sub(11,12)
   local datesec  = Date:sub(13,14)
   
   return (dateyear..'-'..datemth..'-'..dateday..' '..datehour..':'..datemin..':'..datesec)
   
end


function Escape_Characters(element)
   
   --element = element:gsub("&","\\T\\")
   
   return element
   
end

function POSTMessage(call,jsondata)
   
   return net.http.post{url='http://SYKPLOGIAP01V:82/import/'..call,
      --url="http://SVR-BEAMAX02:82/Import/"..functioncall,
      headers={'Content-Type:application/json','charset:utf-8'}, body=jsondata,live=true}
   
end

function ParseResults(resultsdata)
   
   local returnresult = json.parse{data=resultsdata} 
   
end


function SendJsonData(data, event)
   
   trace(data,event)
   
   if event == 'S12' or event == 'S13' or event == 'S14' then
      functioncall = 'CreateOrUpdateCase'
      iguana.logInfo('Create or Update Case')
   else
      functioncall = 'DeleteCase'
      iguana.logInfo('Delete Case')
   end
   
   local jsontransmit = json.serialize{data=data}
   
   if not iguana.isTest() then

      Status, Results = pcall(POSTMessage,functioncall,jsontransmit)      
      trace(Results)
      
   end

   if not Status then
      Results = '{"Result":false,"Message":"Unknown error.  Please contact IT support."}'
   end
   
   return Results
   
end

function ValidateHL7(vmdfile, data)
   
   return hl7.parse{vmd=vmdfile,data=data}
   
end

