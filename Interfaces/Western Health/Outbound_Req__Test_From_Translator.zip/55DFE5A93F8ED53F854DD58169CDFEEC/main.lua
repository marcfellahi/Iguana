-- The main function is the first function called from Iguana.

local function trace(a,b,c,d) return end

function main()
   
   local sourcedir = [[\\WHCBMS54\LogiDataTest\LogiDataRE]]
   local sourceext = "txt"
   
   local result = io.popen("dir /b "..sourcedir..[[\*.]]..sourceext)
   
   trace(result)

   if result ~= nil then
      
      for line in result:lines() do

         local readreqs = io.open(sourcedir..[[\]]..line,"r")
         
         if readreqs ~= nil then
            local readall  = readreqs:read("*all")
            
            jsonreqs = json.parse{data=readall}
      
            trace(jsonreqs)

            ReplenishmentData = ProcessReplenishment(jsonreqs)
            ReplenishmentData = UpdateQtyOnHand(ReplenishmentData)
      
            trace(ReplenishmentData)
      
            ReplenishmentData = json.serialize{data=ReplenishmentData}
            trace(ReplenishmentData)
         
            readreqs:close()

            trace(sourcedir..[[\]]..line)            

            if not iguana.isTest() then
            
               queue.push{data=ReplenishmentData}
               os.remove(sourcedir..[[\]]..line)
            
            end

         end

      end 
      
   end
   
end

function ExtractLocation(field,startposition)

   if startposition == nil then
      startposition = 1
   end
   
   trace(startposition)
   
   if string.find(field,'%.',startposition) == nil then
      
      trace(field,startposition,field:sub(1,startposition-2))
      return field:sub(1,startposition-2)

   else
   
      return ExtractLocation(field,string.find(field,'%.',startposition)+1)
      
   end
   
end

function ProcessReplenishment(jsondata)

   local locationresult = ''
   
   for i =1,#jsondata do

      for j=1,#jsondata do

         if jsondata[i].BinLocation ~= jsondata[j].BinLocation then

            trace(jsondata[i].Qte,jsondata[i].BinLocation,jsondata[j].BinLocation) 
            
            if jsondata[i].BinLocation == 'PROCESSED' or
               jsondata[i].BinLocation == 'DISCARDED' then
               break
            end 
 
            primarylocation   = ExtractLocation(jsondata[i].BinLocation,1)
            secondarylocation = ExtractLocation(jsondata[j].BinLocation,1)
 
            trace(primarylocation,secondarylocation)
            
            if primarylocation == secondarylocation then
               
               jsondata[i].Qte = jsondata[i].Qte - jsondata[j].Qte
               jsondata[i].BinLocation = 'PROCESSED'
               jsondata[j].BinLocation = 'DISCARDED'            
               trace(jsondata[i].Qte,jsondata[i].BinLocation,jsondata[j].BinLocation)
               
            end 
            
            trace(jsondata[i].Qte,jsondata[i].BinLocation,jsondata[j].BinLocation) 
            
         end
         

      end
   
   end
   
   return jsondata
   
end

function UpdateQtyOnHand(jsondata)

   Conn = db.connect{ 
      api=db.SQL_SERVER, name='LogiDataTest',
      user='logidata', password='logidata' 
   }
 
   trace(jsondata)
   for i=1,#jsondata do

      if jsondata[i].BinLocation ~= 'PROCESSED' and
         jsondata[i].BinLocation ~= 'DISCARDED' and
         string.sub(jsondata[i].BinLocation,jsondata[i].BinLocation:len()) ~= 'S'
         then

         SQLinfo = "SELECT ISNULL((SELECT TOP 1 CodePrimaireouSecondaire FROM ProduitDansCasier PDC "..
         "JOIN Departement D ON D.IdDepartement = PDC.IdDepartement "..
         "JOIN Locaux L ON L.IdLocal = PDC.IdLocal "..
         "WHERE D.IdDepartement = '"..jsondata[i].DeptCode.."' and (L.IdLocal = '"..jsondata[i].Room..
         "' and D.IdDepartement = L.IdDepartement) "..
         "and (CodeArmoire + '.' + CAST(Notiroir as nvarchar) + '.' + CodeCasier) = '"..ExtractLocation(jsondata[i].BinLocation)..
         "' and CodePrimaireOuSecondaire <> 'P'),'0') as UA" 
         
         UniqueAdapted = Conn:query{sql=SQLinfo} 

         trace(UniqueAdapted[1].UA:nodeValue() == 'A', SQLinfo) 
         ReturnValue = UniqueAdapted[1].UA:nodeValue()
         
         if ReturnValue == 'A' or ReturnValue == '0' then
            jsondata[i].Qte = 0 
            jsondata[i].BinLocation = 'PROCESSED'
         end
         
         trace(jsondata[i].Qte)
      end
      
   end
   
   Conn:close()
   
   return jsondata
   
end