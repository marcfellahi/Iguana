-- The main function is the first function called from Iguana.

local function trace(a,b,c,d) return end

function main()
   
   local sourcedir = [[\\fjn005\LogiData\LogiDataV3\ProdEnv\LogiDataRE]]
   local sourceext = "txt"
   
   local result = io.popen("dir /b "..sourcedir..[[\*.]]..sourceext)
   
   trace(result)

   if result ~= nil then
      
      for line in result:lines() do

         local readreqs = io.open(sourcedir..[[\]]..line,"r")
         
         if readreqs ~= nil then
            local readall  = readreqs:read("*all")

            jsonreqs = json.parse{data=readall}
      
            trace(jsonreqs)

            ReplenishmentData = ProcessReplenishment(jsonreqs)
            ReplenishmentData = UpdateQtyOnHand(ReplenishmentData)
      
            trace(ReplenishmentData)
      
            ReplenishmentData = json.serialize{data=ReplenishmentData}
            trace(ReplenishmentData)
         
            readreqs:close()

            trace(sourcedir..[[\]]..line)            

            if not iguana.isTest() then
            
               queue.push{data=ReplenishmentData}
               os.remove(sourcedir..[[\]]..line)
            
            end

         end
      end 
      
   end
   
end

function ExtractLocation(field,startposition)

   if startposition == nil then
      startposition = 1
   end
   
   trace(startposition)
   
   if string.find(field,'%.',startposition) == nil then
      
      trace(field,startposition,field:sub(1,startposition-2))
      return field:sub(1,startposition-2)

   else
   
      return ExtractLocation(field,string.find(field,'%.',startposition)+1)
      
   end
   
end

function ProcessReplenishment(jsondata)

   local locationresult = ''
   
   for i =1,#jsondata do

      for j=1,#jsondata do

         if jsondata[i].BinLocation ~= jsondata[j].BinLocation then

            trace(jsondata[i].Qte,jsondata[i].BinLocation,jsondata[j].BinLocation) 
            
            if jsondata[i].BinLocation == 'PROCESSED' or
               jsondata[i].BinLocation == 'DISCARDED' then
               break
            end 
 
            primarylocation   = ExtractLocation(jsondata[i].BinLocation,1)
            secondarylocation = ExtractLocation(jsondata[j].BinLocation,1)
 
            trace(primarylocation,secondarylocation)
            
            if primarylocation == secondarylocation then
               
               jsondata[i].Qte = jsondata[i].Qte - jsondata[j].Qte
               jsondata[i].BinLocation = 'PROCESSED'
               jsondata[j].BinLocation = 'DISCARDED'            
               trace(jsondata[i].Qte,jsondata[i].BinLocation,jsondata[j].BinLocation)
               
            end 
            
            trace(jsondata[i].Qte,jsondata[i].BinLocation,jsondata[j].BinLocation) 
            
         end
         

      end
   
   end
   
   return jsondata
   
end

function UpdateQtyOnHand(jsondata)

   Conn = db.connect{ 
      api=db.SQL_SERVER, name='LogiDataProd',
      user='logidata', password='p1jQcrND'
   }
 
   trace(jsondata)
   for i=1,#jsondata do

      if jsondata[i].BinLocation ~= 'PROCESSED' and
         jsondata[i].BinLocation ~= 'DISCARDED' and
         string.sub(jsondata[i].BinLocation,jsondata[i].BinLocation:len()) ~= 'S'
         then

         -- Changed the condition to check whether an item is unique or adapted.  We now check for the location,
         -- department and product code.  We still check if the codeprimaireousecondaire is different than P.
         -- This new check will consider an item as a double bin if it finds it somewhere else in the room no 
         -- matter if the location is different.  As per Cedric S., implementation Logi-D, this was necessary
         -- since it was pushing double quantities.
         -- Marc Fellahi  2013/09/19  15:39
         --SQLinfo = "SELECT ISNULL((SELECT CodePrimaireouSecondaire FROM ProduitDansCasier PDC "..
         --"JOIN Departement D ON D.IdDepartement = PDC.IdDepartement "..
         --"JOIN Locaux L ON L.IdLocal = PDC.IdLocal "..
         --"WHERE D.IdDepartement = '"..jsondata[i].DeptCode.."' and (L.IdLocal = '"..jsondata[i].Room..
         --"' and D.IdDepartement = L.IdDepartement) "..
         --"and (CodeArmoire + '.' + CAST(Notiroir as nvarchar) + '.' + CodeCasier) = '"..ExtractLocation(jsondata[i].BinLocation)..
         --"' and CodePrimaireOuSecondaire <> 'P'),'0') as UA"

         SQLinfo = "SELECT ISNULL((SELECT TOP 1 CodePrimaireouSecondaire FROM ProduitDansCasier PDC "..
         "JOIN Departement D ON D.IdDepartement = PDC.IdDepartement "..
         "JOIN Locaux L ON L.IdLocal = PDC.IdLocal "..
         "JOIN Produit P ON P.idProduit = PDC.idProduit "..
         "WHERE D.IdDepartement = '"..jsondata[i].DeptCode.."' and (L.IdLocal = '"..jsondata[i].Room..
         "' and D.IdDepartement = L.IdDepartement) and P.Codeproduit = '"..jsondata[i].ProductCode.."'"..
         "and CodePrimaireOuSecondaire <> 'P'),'0') as UA"
  
         trace(SQLinfo)
         
         UniqueAdapted = Conn:query{sql=SQLinfo} 

         trace(UniqueAdapted[1].UA:nodeValue() == 'A', SQLinfo) 
         ReturnValue = UniqueAdapted[1].UA:nodeValue()
         
         if ReturnValue == 'A' or ReturnValue == '0' then
            -- Added a new condition that checks if the quantity is greater than 1.  If it is, then put it at 0.
            -- If not, then it will leave the qty ordered as is (1)
            -- This change is as per the request of Cedric S., implementation Logi-D, because in Meditech
            -- bins cannot be created with a MSQ of 1 since Meditech does a calculation of MSQ - MRP and the result
            -- must be greater than 1.  
            -- Marc Fellahi  2013/09/23  15:39
            if jsondata[i].Qte+0 > 1 then
               jsondata[i].Qte = 0
            end
            jsondata[i].BinLocation = 'PROCESSED'
         end
         
         trace(jsondata[i].Qte)
      end
      
   end
   
   Conn:close()
   
   return jsondata
   
end