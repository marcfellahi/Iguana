function CloseDatabaseHandling(PrintStatement, connection, messages)

   if messages == nil then
      
      messages = ''
         
   end
      
   print(PrintStatement)
   
   Status, ErrorString = pcall(SQLExecute, connection, 'ROLLBACK TRANSACTION')
   
   if not Status then
      
      print(messages.Error_DBRollBack[1]..ErrorString)
      
   end
   
   connection:close()
   
end

function SQLExecute(connection, SQLStatement)
   
   return connection:execute(SQLStatement)      
   
end


function SQLQuery(connection, SQLstatement)
   
   return connection:query(SQLstatement)
   
end