require('filehandling')
require('LdIguanaFileLibrary')
require('stringutil')

local function trace(a,b,c,d) return end

local incomingfile       = "X12850"
sourcedirectory    = [[\\mmvlogidappsrv\Version\LogiDataRECC\]]

trace(sourcedirectory)

function main()
   
   local data
   local filenames = scandir(sourcedirectory)

   if filenames ~= nil then
   
      for i=1,#filenames do
            
         uppername = filenames[i]:upper()

         if uppername:find(incomingfile) ~= nil then
            
            k, j = uppername:find(incomingfile)
            
            local filetobeprocessed = string.upper(string.sub(filenames[i],k,j+4))
            --print('Filename: ',filetobeprocessed)

            data = ProcessFile(sourcedirectory, filetobeprocessed, replacedmatch, DeliveryShipmentCode, deliverymatch)

            if not iguana.isTest() then 
               
               queue.push{data=data}      

               removeFile(sourcedirectory..filetobeprocessed)      
               
            end         
         end

      end

   end

end


function ProcessFile(directory, file, replacedtext, deliverytext, striptextPO)

   local data           = ''
   local fileandpath    = directory..file

   local fileopen = assert(io.open(fileandpath, "r"), "Could not open file: "..fileandpath)

   local CostCenter = ''
   local Shipto = ''
         
   if fileopen ~= nil then
     
      Currentpost = fileopen:seek()
      
      for line in fileopen:lines() do

         if line:find('CostX12') then

            CostCenter = line:sub(line:find('CostX12')+8)
            trace(CostCenter)
            
         end
         
         if line:find('ShipX12') then
            
            Shipto = line:sub(line:find('ShipX12')+8)
            trace(Shipto)
            
         end
         
      end
      
      fileopen:seek("set",Currentpost)
      
      for line in fileopen:lines() do

         IncludeLine = true
         
         if line:find('CostX12') or line:find('ShipX12') then
            
            IncludeLine = false
         
         end
         
         if IncludeLine then
            
            if line:find('$CostCenter') then
               
               line = line:gsub('$CostCenter',CostCenter)
               trace(line)
               
            end
            
            if line:find('$ShipTo') then
               
               line = line:gsub('$ShipTo',Shipto)
               trace(line)
               
            end
            
            trace(line)
            data = data..line..'\r\n'
            
         end
         
         trace(data)

      end
      
      io.close(fileopen)
      
   end
   
   --print('complete segment: ',data)

   return data

end

function scandir(directory)
   
   local counter = 1
   local nameindex = {}
   
   
   local filenames = io.popen('dir /b '..directory)
   trace(filenames)
   local list      = filenames:read('*a')
   
   for k,v in pairs(list:split('\n')) do

      local listname = v:upper()
      
      if listname:find('X12850') ~= nil then
      
         nameindex[counter] = v
         counter = counter + 1

      end
      
   end
   
   trace(nameindex)
      
   return nameindex
   
end   
