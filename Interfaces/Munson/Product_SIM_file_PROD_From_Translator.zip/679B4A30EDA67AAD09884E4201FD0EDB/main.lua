require('dbc')
require('DBOperations')

function trace (a,b,c,d) return end

-- The main function is the first function called from Iguana.
function main()
 
   currenttime = os.date("%H%M%S")
   beglaunchtime = '020000'
   endlaunchtime = '020200'
   --beglaunchtime = '090600'
   --endlaunchtime = '090800'
   
   trace(currenttime,beglaunchtime,endlaunchtime)
   
   -- This section allows us to run the sripts once a day.  If the current time is in between the
   -- scheduled time, then channel launches.  15:52  2013/05/31  FM
   if currenttime >= beglaunchtime and currenttime <= endlaunchtime then
      --We are ok.  The channel can run.  Else we exit
   else
      return
   end
   
   local MessFile = io.open([[\\mmvlogidappsrv\TestEnv\LogiDataExe\Interfaces\McKesson\messages.en.xml]])
   local MessFileRead = MessFile:read("*all")
   MessFile:close()
   
   -- The reason we're inquiring test is before going Live, we need the latest data from the production 
   -- environment and since this is only for creating a file, it does not impact any processes
   -- Marc Fellahi 2013/06/21  FM
   local Inbound  = io.open([[\\mmvlogidappsrv\Version\LogiDataExe\Interfaces\McKesson\inboundsettings.xml]])
   local InboundFileRead = Inbound:read("*all") 
   Inbound:close()
   
   local Msg = {}
   Msg = Load_Messages(xml.parse{data=MessFileRead})
   
   local Settings = {}
   Settings = Load_Messages(xml.parse{data=InboundFileRead})    

   trace(Settings, Msg)
   
   local Message_Dir     = [[C:\Waveforms\Import\]]
   local MessageFileName = 'Import_'..os.date('%y%m%d%H%M%S')..'.TXT'

   trace(MessageFileName)

   conn = dbc.Connection{         
      api=db.SQL_SERVER,
      name=Settings.DB_name[1],
      user=Settings.DB_username[1], 
      password=Settings.DB_password[1],
      use_unicode=true,
      live=true
   }
   
   local SQLstatement = [[select CodeProduit, CASE ltrim(rtrim(UD1)) ]]..
   [[WHEN '' then 'Unknown' when null then 'Unknown' else UD1 End as SIMCode, ]]..
   [[VirtuoDestImputation  from logidata.Produit]]

   Status, ResultSQL = pcall(SQLQuery,conn,SQLstatement)

   trace(ResultSQL)

   if not Status then
      
      iguana.logError('Cannot retrieve Product items with SIM code') -- CONNECTION ERROR MESSAGE
      conn:close()
      return
         
   end   

   local SIMFile = ''
   
   for item = 1,#ResultSQL do
      
      trace(ResultSQL[item])
      SIMFile = SIMFile..ResultSQL[item].CodeProduit..','..ResultSQL[item].SIMCode..','..
      ResultSQL[item].VirtuoDestImputation..'\r'
      
   end
   
   trace(SIMFile)

   if not iguana.isTest() then
   
      queue.push{data=SIMFile}   
      
   end
      
end


function Load_Messages(Data)

local MessageTable = {}

   for i=1, Data.entries:childCount('entry') do

      MessageTable[Data.entries[i].key[1]:nodeValue()] = {Data.entries[i].value[1]:nodeValue()}

   end
   
   return MessageTable
end