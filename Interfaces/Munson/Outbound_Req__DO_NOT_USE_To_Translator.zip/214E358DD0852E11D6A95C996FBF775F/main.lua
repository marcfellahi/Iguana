-- The main function is the first function called from Iguana.
-- The Data argument will contain the message to be processed.
function trace (a,b,c,d) return end

function main(Data)
   
   local remotepath = 'logidprod'
   
   local ftp = net.ftp.init{server='mmc-ftp158',username=[[munson\srvlogidsupp]],password='Dh4JMgCth8',live=true}

   local RemoteDir = ftp:list{remote_path='/'..remotepath}   

   trace(RemoteDir)
  
   counter = 1 
   existingFiles = {}
   
   for key, filelist in pairs(RemoteDir) do

      trace(key, filelist.filename)
      RemoteFile = string.upper(filelist.filename)
      trace(RemoteFile)
      
      TestValue = RemoteFile:find(".",1,plain)


      if RemoteFile:find('X12850') then
         
         existingFiles[counter] = RemoteFile
         counter = counter + 1
         trace(existingFiles)
         
      end
      
   end
   
   trace(existingFiles)

   extension = '001'
   newfilename = 'X12850.'

   for key, existingfile in pairs(existingFiles) do
      
      newfilename = 'X12850.'
      
      trace(existingfile, newfilename..extension)
      
      if existingfile == newfilename..extension then
         
         extension = string.format("%03d",extension+1)
         
         --extDig = RemoteFile:sub(RemoteFile:find('.',1,true)+1)
         --if (extension + 0) < 10 then
         --   extension = '00'..(extension + 1)
         --   trace(extension)
         --else
         --   if (extension + 0) > 9 and (extension +0) < 100 then
         --      extension = '0'..(extension + 1)
         --      trace(extension)
         --   else
         --     extension = extension + 1
         --      trace(extension)
         --   end
         --end
   
      end      
      
   end
   
   trace(newfilename..extension)

   trace(remotepath,newfilename,extension)
   
   if not iguana.isTest() then
      
      ftp:put{remote_path='/'..remotepath..'/'..newfilename..extension,data=Data}
      
   end
   
end