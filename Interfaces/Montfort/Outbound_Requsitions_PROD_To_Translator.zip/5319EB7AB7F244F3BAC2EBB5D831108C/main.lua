function trace(a,b,c,d) return end

-- The main function is the first function called from Iguana.
-- The Data argument will contain the message to be processed.
function main(Data)

   local IncomingReq = json.parse{data=Data}

   -- Sometimes LogiDATA will push empty requisitions ([] only sent) that have 
   -- no element and this will create a problem on the interface side.  It does
   -- not know what to do with the empty json table.  We will use a pcall
   -- with a function and test for error if the element does not exist
   local Status, Result = pcall(CheckTableEmpty,IncomingReq)
   
   if not Status then
      return
   end

   
   -- milliseconds timestamp
   local a,b = math.modf(os.clock())
   if b==0 then
      b='000'
   else
      b=tostring(b):sub(3,5)
   end
   
   b=b:gsub('%.','')
   
   local Extension   = "HHT"
   local Namecounter = "001"
   local OutputDir   = [[\\pap-a03\Version\Meditech\Outbound\]]
   local OutputName  = IncomingReq[1].CostCenter
   local TodaysDate  = os.date("%Y%m%d%H%M%S")..b
   
   TotalReqBatches  = 0
   TotalReqLines = 0
   
   trace(OutputName,TodaysDate,IncomingReq)
  
   local Newfilename = OutputName..TodaysDate..Namecounter.."."..Extension

   NbrCostCenter = TotalCostCenters(IncomingReq)
   SortedCenters = SortJSONarray(NbrCostCenter,IncomingReq)
   
   ReqText       = CreateHeader()
   
   for i=1,#NbrCostCenter do

      TotalReqBatches = TotalReqBatches + 1
      TotalLines   = 0

      ReqText = ReqText..CreateSubHeader(NbrCostCenter[i])
                  
      for j=1,#SortedCenters do
         
         if SortedCenters[j].CostCenter == NbrCostCenter[i] then
            
            ReqText = ReqText..CreateReq(SortedCenters[j])

         end
            
      end

      ReqText = ReqText..CreateSubFooter()

   end

   ReqText = ReqText..CreateFooter(TotalReqBatches)
      
   trace(ReqText)

   for FileName, FileInfo in os.fs.glob(OutputDir..OutputName..'*.*') do  
      
      trace(line)
      local Fileexists = true
      
      while(Fileexists) do
         
         trace(FileName,OutputDir..Newfilename)
      
         if FileName == OutputDir..Newfilename then
         
            Namecounter = string.format("%03d",Namecounter+1)
            Newfilename = OutputName..TodaysDate..Namecounter.."."..Extension
            
         else
            
            Fileexists = false
            
         end

      end

   end
   
   if not iguana.isTest() then
   
      local OutputInfo = io.open(OutputDir..Newfilename,"w")
      OutputInfo:write(ReqText)
      OutputInfo:close()
   
   end
  
end


function CheckTableEmpty(Data)

   return Data[1].CostCenter
   
end


function CreateFooter(Batches)

   return '999 '..string.format("%06d",Batches)..string.format("%06d",TotalReqLines)..'\n'
   
end


function CreateHeader()
   
   CurrentDate = os.date("%Y%m%d")
   
   local OutputHeader = '001 '..CurrentDate..'\n'

   return OutputHeader
   
end


function CreateSubFooter()
   
   return '990 '..string.format("%06d",TotalLines)..'\n'
     
end

function CreateSubHeader(IncomingData)
   
   return '030 '..string.format("%-10s",IncomingData)..CurrentDate..'\n'

end


function CreateReq(IncomingData)

   local OutputReturn = ''
   

   if IncomingData.BinLocation ~= 'DISCARDED' then
         
      TotalLines    = TotalLines + 1
      TotalReqLines = TotalReqLines + 1
      OutputReturn  = OutputReturn..'031 '..string.format("%-10s",IncomingData.ProductCode)..string.format("%010d",IncomingData.Qte)..'\n'

   end
   
   return OutputReturn
   
end


function TotalCostCenters(IncomingData)
   
   local ListCostCenter = {} 
   
   for i=1,#IncomingData do
   
      AddCostCenter = true
      for j=1,#ListCostCenter do
 
         trace(IncomingData[i].CostCenter,ListCostCenter[j],AddCostCenter)
         if ListCostCenter[j] == IncomingData[i].CostCenter then
              
            AddCostCenter = false
               
         end
            
      end
      
      trace(ListCostCenter,AddCostCenter)
      
      if AddCostCenter then
         ListCostCenter[#ListCostCenter+1] = IncomingData[i].CostCenter
      end
      
      trace(ListCostCenter)
      
   end

   return ListCostCenter
   
end


function SortJSONarray(ListCostCenter,IncomingData) 
   
   local SortedData = {}
         
   for i=1,#ListCostCenter do
      
      for j=1,#IncomingData do
   
         if IncomingData[j].CostCenter == ListCostCenter[i] then
            SortedData[#SortedData+1] = IncomingData[j]
         end
         
      end

   end      

   trace(SortedData)
   
   return SortedData
end