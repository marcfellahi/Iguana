require('split')

function trace (a,b,c,d) return end
-- The main function is the first function called from Iguana.
function main()
   
   local reqdir = [[\\SRHCRFID\LogiData\LogiDataV3\TestEnv3.3\LogiDataRE\JIT\]]
   
   local incomingfiles = {}
   
   incomingfiles = scandir(reqdir,"LOGIIDJIT")
   
   trace(incomingfiles)
   
   for i=1,#incomingfiles do 
      
      Data = ProcessFile(incomingfiles[i])
      
      trace(Data)
      
      if not iguana.isTest() then
         
         queue.push{data=Data}
         os.remove(incomingfiles[i])

      end
      
   end   
      
end


function Escape_Characters(linedata)

   local findchar = linedata:find("@@@")
   
   if findchar == nil then
      return linedata
   end
   
   local extractpartone = linedata:sub(1,linedata:find("@@@")-1)
   local extractpartdata = linedata:sub(linedata:find("@@@")+3,linedata:find("@@@,")-1)
   
   extractpartdata = extractpartdata:gsub("'","&quot;")
   extractpartdata = extractpartdata:gsub("&","&amp;")
   extractpartdata = extractpartdata:gsub(">","&gt;")
   extractpartdata = extractpartdata:gsub("<","&lt;")
   
   linedata = extractpartone.."'"..extractpartdata.."',"
   
   return linedata
   --extractpartone = 
   
end

function ProcessFile(file)

   local data           = ''

   local Status, fileopen = pcall(io.open,file, "r")

   trace(fileandpath, Status, fileopen)
            
   if fileopen ~= nil then
      
      for line in fileopen:lines() do

         trace(line)
         line = Escape_Characters(line)
         data = data..line
         
      end
      
      trace(data)
      io.close(fileopen)
      
   end
   
   --print('complete segment: ',data)

   return data

end

function scandir(directory, fileext)
   
   local counter = 1
   local nameindex = {}
   
      
   for Filename,FileInfo in os.fs.glob(directory..'\*.*') do

      nameindex[counter] = Filename
      counter = counter + 1
     
   end
   

   trace(nameindex)
      
   return nameindex
   
end   