require('retry')

function trace(a,b,c,d) return end
-- The main function is the first function called from Iguana.
-- The Data argument will contain the message to be processed.
function main(Data)
   

   local configfile = [[C:\Program Files\iNTERFACEWARE\Iguana\iguanaconfiguration.xml]]
   local openconfig = io.open(configfile,'r')
   local readconfig = openconfig:read("*all")
   openconfig:close() 
   
   local parseconfig = xml.parse{data=readconfig}
   
   local emaillist = {}
   local k = 1
   
   for i=1,parseconfig.iguana_config.auth_config:childCount("user") do

      for j=1,   parseconfig.iguana_config.auth_config:child("user", 2):childCount("group") do
         
         if parseconfig.iguana_config.auth_config:child("user", i):child("group", j).name:nodeValue() == 'Critical Items warning' then
            
            emaillist[k] = parseconfig.iguana_config.auth_config:child("user",i).email_address:nodeValue()
            k = k + 1
            
         end
         
      end
      
   end

   local smtpserver = parseconfig.iguana_config.email_config.smtp_host:nodeValue()
   local smtpport = parseconfig.iguana_config.email_config.smtp_port:nodeValue()
   local smtpsender = parseconfig.iguana_config.email_config.sender_email_address:nodeValue()
   local smtpuser = parseconfig.iguana_config.email_config.smtp_user_name:nodeValue()
   local smtppass = parseconfig.iguana_config.email_config.smtp_password:nodeValue()

   trace(emaillist)
   
   if not iguana.isTest() then
      --net.smtp.send{server=smtpserver,from=smtpsender,to={emaillist},
      --   header={['Subject']='Logid System Stockout'},body=Data,live=true,debug=true}

      local results = retry.call{func=net.smtp.send,arg1={server=smtpserver,username=smtpuser,
                     password='southlake4521',from=smtpsender,to=emaillist,
                     header={['Subject']=[[CRITICAL ITEMS]]},body=Data,live=true,debug=true, 
                     use_ssl=[[try]],timeout=120},
                     retry=5,pause=30}
   
   end
   
end