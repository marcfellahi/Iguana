function trace (a,b,c,d) return end
-- The main function is the first function called from Iguana.
-- The Data argument will contain the message to be processed.
function main(Data)
   
   trace(Data)
   
   if Data == '' then
      return
   end
   
   XMLData = json.parse{data=Data}
   
   local CardinalRec = {}
   local COHPARec = {}
   

   for i=1,#XMLData do
      
      if XMLData[i].SendCardinal == 'Y' then
         trace(CardinalRec)
         CardinalRec[#CardinalRec+1] = XMLData[i]
      else
         COHPARec[#COHPARec+1] = XMLData[i]
      end
      
   end
   
   trace(CardinalRec,COHPARec)
   local CardinalData = ''
   local COHPAData    = ''
   
   if #CardinalRec >= 1 or #COHPARec >= 1 then
      
      if #CardinalRec >= 1 then
         CardinalData = Build_Cardinal(CardinalRec)
         CardinalData = Wrap_Text(CardinalData)
      end
      
      if #COHPARec >= 1 then
         COHPAData = Build_COHPA(COHPARec)
      end
      
   end
   
   trace(CardinalData, COHPAData)

   -- We send the file first to the directory for Cardinal
   -- Marc Fellahi  2013/07/09  12:21pm
   local remotepath = '/ftp_TestIN/logid2card/'
   --local remotepath = '/ftp_ProdIN/logid2card/'
   local ftp = net.ftp.init{server='172.23.250.10',username=[[CohpaFtp1]],password='CohpaFtp1!',
      no_epsv=true,timeout=30,live=true}        
   local CardinalDir = ftp:list{remote_path=remotepath}          
   
   trace(CardinalDir)       
   counter = 1     
   existingFiles = {}        
   
   for key, filelist in pairs(CardinalDir) do       
      
      trace(key, filelist.filename)       
      
      RemoteFile = string.upper(filelist.filename)       
      
      trace(RemoteFile)              
      
      TestValue = RemoteFile:find(".",1,plain)         
      
      if RemoteFile:find('LOGIID') then                    
         
         existingFiles[counter] = RemoteFile          
         counter = counter + 1         
         trace(existingFiles)                 
      
      end           
   
   end        

   local a,b = math.modf(os.clock())
   if b==0 then 
      b='000' 
   else 
      b=tostring(b):sub(3,5) 
   end
   
   trace(existingFiles)     
   extension = '001'    
   cardinalfile = 'LOGIID'..os.date("%m%d%Y%H%M%S")..b..'.'..extension
   trace(cardinalfile)        
   
   for key, existingfile in pairs(existingFiles) do                         
      
      cardinalfile = 'LOGIID'..os.date("%m%d%Y%H%M%S")..b..'.'..extension
      trace(existingfile, cardinalfile)              
      
      if existingfile == cardinalfile then                   
         
         extension = string.format("%03d",extension+1)                      

      end                 
   
   end        
   
   trace(cardinalfile,extension)     
   
   if not iguana.isTest() then             
      ftp:put{remote_path=remotepath..cardinalfile,data=CardinalData}                   
   end

   local remotepath = '/ftp_TestIN/reqs'
   --local remotepath = '/ftp_ProdIN/'
   local COHPADir = ftp:list{remote_path=remotepath}          
   
   trace(COHPADir)       
   counter = 1     
   existingFiles = {}        
   
   for key, filelist in pairs(COHPADir) do        
      
      trace(key, filelist.filename)       
      
      RemoteFile = string.upper(filelist.filename)       
      
      trace(RemoteFile)              
      
      TestValue = RemoteFile:find(".",1,plain)         
      
      if RemoteFile:find('LOGIID') then                    
         
         existingFiles[counter] = RemoteFile          
         counter = counter + 1         
         trace(existingFiles)                 
      
      end           
   
   end        
   
   trace(existingFiles)     
   extension = '001'    
   cohpafile = 'LOGIID'..os.date("%m%d%Y%H%M%S")..b..'.'..extension
   trace(cohpafile)        
   
   for key, existingfile in pairs(existingFiles) do                         
      
      cohpafile = 'LOGIID'..os.date("%m%d%Y%H%M%S")..b..'.'..extension
      trace(existingfile, cohpafile)              
      
      if existingfile == cohpafile then                   
         
         extension = string.format("%03d",extension+1)                      

      end                 
   
   end        
   
   trace(cohpafile,extension)     
   
   if not iguana.isTest() then              
      ftp:put{remote_path=remotepath..cohpafile,data=COHPAData}                   
   end
   
end

function Build_Cardinal(data)
   
   --newreq = Build_Header("ZZ","LOGIIDP","P","306010759",data,'~')
   newreq = Build_Header("ZZ","LOGIIDT","T","306010682",data,'~')
   newreq = newreq..Build_POTrailer("CARDINAL",data,'~')
   
   trace(newreq)
   
   return newreq
   
end

function Build_COHPA(data)
   
   newreq = Build_Header("01","LOGIID","T","COHPA PMM",data)
   newreq = newreq..Build_POTrailer("COHPA",data)
   
   trace(newreq)
   
   return newreq
   
end

function Build_Header(Seq5or7,Seq6,Seq15,Seq8,jsondata,charterminator)
   
   local switchline = ''
   
   if charterminator == nil then
      charterminator = ''
      switchline     = "\r\n"
   else
      Seq6 = string.format("%-15s",Seq6)
      Seq8 = string.format("%-15s",Seq8)
   end
   
   local currentdate = os.date('%y%m%d')
   local currenttime = os.date("%H%M")
   
   trace(Seq5or7,Seq6,Seq15,Seq8)
      
   local HeaderISA = "ISA^00^"..string.format("%10s"," ").."^00^"..string.format("%10s"," ")
   .."^"..Seq5or7.."^"..Seq6.."^"..Seq5or7.."^"..Seq8
   .."^"..currentdate.."^"..currenttime.."^U^00204^"..string.format("%09d",jsondata[1].ReplNumber)
   
   trace(switchline,Seq6, Seq8)
   if switchline == '' then
      HeaderISA = HeaderISA.."^0^"..Seq15.."^|"..charterminator
   else
      HeaderISA = HeaderISA.."^0^"..Seq15.."^^^^"..charterminator..switchline
   end
   
   HeaderGS = "GS^PO^"..Seq6.."^"..Seq8.."^"..currentdate.."^"..currenttime.."^"
   ..jsondata[1].ReplNumber.."^X^002004"..charterminator..switchline
   
   trace(HeaderGS)
   
   HeaderST   = "ST^850^"..currentdate..charterminator..switchline
   HeaderBEG  = "BEG^00^SA^SRLD"..string.format("%012d",jsondata[1].ReplNumber).."^"
   ..charterminator..switchline
   HeaderDTM  = "DTM^097^"..currentdate.."^"..currenttime..charterminator..switchline
   HeaderN1BY = "N1^BY^^92^"..jsondata[1].Shipto.."^1002^3043"..charterminator..switchline
   HeaderN1ST = "N1^ST^"..jsondata[1].DescDept.."^92"
   
   if switchline == '' then
      HeaderN1ST= HeaderN1ST..'^'..jsondata[1].DescDept..charterminator
   else
      HeaderN1ST= HeaderN1ST..switchline
   end

   Header = HeaderISA..HeaderGS..HeaderST..HeaderBEG..HeaderDTM..HeaderN1BY..HeaderN1ST

   return Header
   
end

function Build_POTrailer(recipient,data,charterminator)

   local switchlines = ''
   
   if charterminator == nil then
      charterminator = ''
      switchlines    = "\r\n"
   end
   
   trace(recipient,data)
   
   local currentdate = os.date("%y%m%d")
   local PO1         = ''
   local PID         = ''
   local POLines     = ''
   local linecounter = 0
   local totalqties  = 0

   -- This counter is used for Cardinal.  Cardinal need to have the number of
   -- segments from the ST to SE segments, both included in it.  We start the
   -- counter at 5 for the ST, BEG, DTM, N1^BY & N1^ST segments.
   -- Marc Fellahi  2013/07/17  FM
   local secountseg  = 5
   
   for i=1,#data do 
   
      linecounter = linecounter + 1
      totalqties  = totalqties + data[i].OrderQty
      
      if recipient == 'CARDINAL' then
         
         PO1 = "PO1^"..string.format("%06d",linecounter).."^"..string.format("%05d",data[i].OrderQty)
         .."^"..string.format("% s",data[i].OrderUnit:upper()).."^^^VC^"..data[i].VendProdCode.."^BP^"
         ..data[i].ProdCode.."^^^MG^"..data[i].VendProdCode.."^IN^"..data[i].ProdCode..charterminator..switchlines       
         PID = "PID^F^^^^^"..data[i].ProdDesc..charterminator..switchlines
         
         POLines = POLines..PO1..PID

      else
          
         PO1 = "PO1^"..string.format("%06d",linecounter).."^"..string.format("%05d",data[i].OrderQty)
         .."^"..string.format("% s",data[i].OrderUnit:upper()).."^^^^^^^^^^^BP^"..data[i].ProdCode.."^CG^^^^^"..switchlines
         PID = "PID^ ^^^^^"..data[i].ProdDesc..switchlines
 
         POLines = POLines..PO1..PID
         
      end
      
      secountseg = secountseg + 2
      
   end

   -- We add two more to the count of segments for the SE segment.  This + 2 is for the CTT & SE segemnt
   -- Marc Fellahi 2013/07/17
   secountseg = secountseg + 2
   
   TrailerCTT = "CTT^"..string.format("%06d",linecounter).."^"..string.format("%010d",totalqties)..charterminator..switchlines
   
   if recipient == 'CARDINAL' then
      TrailerSE  = "SE^"..string.format("%06d",secountseg).."^"..currentdate..charterminator..switchlines
   else
      TrailerSE  = "SE^000001^"..currentdate..charterminator..switchlines
   end
   
   TrailerGE  = "GE^000001^"..currentdate..charterminator..switchlines      
   TrailerIEA = "IEA^000001^"..string.format("%09d",data[1].ReplNumber)..charterminator..switchlines
   
   LinesandTrailer = POLines..TrailerCTT..TrailerSE..TrailerGE..TrailerIEA
   
   return LinesandTrailer
   
end

function Wrap_Text(texttowrap)
   
   local wrappedtext = ''
   local stillwrap = true
   
   while stillwrap do
      
      if texttowrap:len() > 80 then         
         wrappedtext = wrappedtext..texttowrap:sub(1,80).."\r\n"
         texttowrap  = texttowrap:sub(81)
         trace(texttowrap)
      else         
         wrappedtext = wrappedtext..texttowrap.."\r\n"
         stillwrap = false         
      end
      
   end
   
   trace(wrappedtext)
   return wrappedtext
   
end