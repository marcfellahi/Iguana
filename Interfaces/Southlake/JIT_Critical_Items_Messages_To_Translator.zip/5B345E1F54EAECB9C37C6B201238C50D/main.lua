-- The main function is the first function called from Iguana.
-- The Data argument will contain the message to be processed.
function main(Data)
   
   local DataHeader = [[CRITICAL ITEMS NOTIFICATION]]..'\n'..
   [[The following critical items have been put on board for replenishments:]]..'\n\n'      

   DataHeader = DataHeader..Data

   if Data ~= '' then
      iguana.logInfo(DataHeader)   
   end

end