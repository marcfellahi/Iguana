require('dbc')
require('iguanaconfig')

function trace(a,b,c,d) return end
-- This channel will check if a tag goes on board and it is a critical JIT items.  If it is, send an email to
-- the appropriate ressources
-- Marc Fellahi  2013/09/26
-- The main function is the first function called from Iguana.
function main()

   local Inbound  = io.open([[\\SRHCrfid\LogiData\LogiDataV3\ProdEnv\LogiDataExe\Interfaces\McKesson\inboundsettings.xml]])  
   local InboundFileRead = Inbound:read("*all") 
   Inbound:close()
   
   local Settings = {}
   Settings = Load_Messages(xml.parse{data=InboundFileRead})     

   trace(Settings, Msg)
   
   conn = dbc.Connection{         
         api=db.SQL_SERVER,
         name=Settings.DB_name[1],
         user=Settings.DB_username[1], 
         password=Settings.DB_password[1],
         use_unicode=true,
         live=true
         }
   
   local UpdateWarning = [[UPDATE Logidata.ProduitDansCasier ]]..
   [[SET UD2 = '' ]]..
   [[WHERE UD2 = 'Warning' and IDProduitDansCasier NOT IN (SELECT L.IDProduitDansCasier FROM Logidata.Lectures L ]]..
   [[JOIN Logidata.ProduitDansCasier PDC ON PDC.IDProduitDansCasier = L.IDProduitDansCasier ]]..
   [[JOIN Logidata.ProduitDeptLocal PDL ON PDL.IDProduit = PDC.IDProduit ]]..
   [[AND PDL.IdDepartement = PDC.IdDepartement AND PDL.IdLocal = PDC.IdLocal WHERE PDL.CodeSource = 'JT' and PDC.UD1 != 'Y')]]
   
   local result = conn:execute(UpdateWarning)
   
   local QueryPDC = [[SELECT PDC.idProduitDansCasier, P.CodeProduit, P.Description , D.IdDepartement, ]]..
   [[D.Description [DeptDesc], LO.IdLocal, LO.Description [RoomDesc], ]]..
   [[(PDC.CodeArmoire + '.' + CAST(PDC.NoTiroir as varchar) + '.' + PDC.CodeCasier + '.' + PDC.CodePrimaireOuSecondaire) [Bin], ]]..
   [[PDC.QteDansCeCasier, PDL.UniteQuota ]]..
   [[FROM Logidata.Lectures L WITH (NOLOCK) ]]..
   [[JOIN Logidata.ProduitDansCasier PDC ON PDC.IDProduitDansCasier = L.IDProduitDansCasier ]]..
   [[JOIN Logidata.ProduitDeptLocal PDL ON PDL.IDProduit = PDC.IDProduit AND ]]..
   [[PDL.IdDepartement = PDC.IdDepartement AND PDL.IdLocal = PDC.IdLocal ]]..
   [[JOIN Logidata.Produit P ON P.IDProduit = pdc.IDProduit ]]..
   [[JOIN Logidata.Departement D ON D.IdDepartement = PDC.IdDepartement ]]..
   [[JOIN Logidata.Locaux LO ON LO.IdDepartement = PDC.IdDepartement and LO.IdLocal = PDC.IdLocal ]]..
   [[WHERE PDC.UD2 != 'Warning' AND PDL.CodeSource = 'JT' AND PDC.UD1 != 'Y']]
  
   
   local result = conn:query(QueryPDC)
   
   trace(result)
   
   if not iguana.isTest() then

      local WarningLog = '' 
      
      for i=1,#result do

         trace(test)
         
         WarningLog = WarningLog..[[CRITICAL ITEM (]]..result[i].CodeProduit..[[) ]]..
         string.format("%-20s ",result[i].Description:nodeValue()):sub(1,20)..
         [[ (]]..result[i].idDepartement..[[) ]]..result[i].DeptDesc..[[ / (]]..
         result[i].idLocal..[[) ]]..result[i].RoomDesc..[[ ]]..result[i].Bin..[[ ]]..
         result[i].QteDansCeCasier..[[ ]]..result[i].UniteQuota..'\n\r'
         
         local UpdatePDC = [[UPDATE Logidata.ProduitDansCasier ]]..
         [[SET UD2 = 'Warning' ]]..
         [[WHERE idProduitDansCasier = ]]..result[i].idProduitDansCasier
         trace(UpdatePDC)      
         conn:execute(UpdatePDC)
         
      end   
      
      if #result > 0 then
         queue.push{data=WarningLog}
      end
      
   end
    
end