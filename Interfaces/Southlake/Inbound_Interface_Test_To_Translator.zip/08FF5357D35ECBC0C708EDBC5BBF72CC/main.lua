require('files')
require('stringutil')
require('sqlescape')

local function trace(a,b,c,d,e,f,g,h,i) return end

EscapeValue = sqlescape.EscapeFunction(db.SQL_Server)

--function main(Data)
function main(Data)

   print("Beginning of process")
   
   -- For Debug Purposes
   -- Permits to see the data being passed from the "From Translator"
   -- Marc Fellahi  2012/10/23  9:13
   --print("Initial Data: ", Data)
   
   local CSVData=parseCSV(Data)
   
   -- For Debug Purposes
   -- Permits to see the data being passed after being transformed
   -- Marc Fellahi  2012/10/23  9:13
   --print("To Translator: ",CSVData)

   ProcessCSV(CSVData)

   print("End of process") 
   
end

function parseCSV(Data)

   local CSVSplit=Data:split('\n')
   local CleanCSV={}
   local CSVTransform={}

   for i=1,#CSVSplit do
      
      CleanCSV[i]={}
      
      --print("bug: ",CSVTransform)
      CSVTransform=CSVSplit[i]:splitQ(',','"')
      --print("bug: ",CSVTransform)
      
      for j=1,#CSVTransform do 
      
         CleanCSV[i][j]=CSVTransform[j]:trimWS()
         
      end
      
   end

   return CleanCSV

end

function ProcessCSV(csv)
   
   local UnRowCnt=0 --uprocessed rows
   
   for i=1,#csv do

      -- This specific condition in the loop is necessary because the first line contains
      -- the name of the file and the second line contains the headers.  To be able to 
      -- process thes lines, we need to exclude them from being passed to the function
      -- ProcessItem
      -- Marc Fellahi  2012/10/23  9:13
      if not csv[i][1]:find(".csv") and not csv[i][1]:find("Number") then
         trace("CSV info: " ,csv[i], "CSV counter: ", i)
         ProcessItem(csv[i])
      else
         UnRowCnt=UnRowCnt+1
      end
      
   end
   
   return 
   
end

function ProcessItem(csv)

   local SQL_Fournisseurs = {}
   local SQL_Produit = {}
   local SQL_ProdutFourn = {}
   
   -- Definition of csv file
   -- csv(1)  - Number
   -- csv(2)  - Status
   -- csv(3)  - Description
   -- csv(4)  - Description 1
   -- csv(5)  - Vendor Name
   -- csv(6)  - Vendor Number
   -- csv(7)  - Manufacturer
   -- csv(8)  - Mfr Catalog Number
   -- csv(9)  - UM 1
   -- csv(10) - Cat. No 1
   -- csv(11) - Conv. Fact. 1
   -- csv(12) - Price 1
   -- csv(13) - UM 2
   -- csv(14) - Cat. No 2
   -- csv(15) - Conv. Fact. 2
   -- csv(16) - Price 2
   -- csv(17) - UM 3
   -- csv(18) - Cat. No 3
   -- csv(19) - Conv. Fact. 3
   -- csv(20) - Price 3
   -- csv(21) - UM 4
   -- csv(22) - Cat. No 4
   -- csv(23) - Conv. Fact. 4
   -- csv(24) - Price 4   

   -- For Debug purposes
   -- Before running the SELECT query I log the value of the CSV line
   -- Marc Fellahi  2012/10/23  9:13
   trace("Statement before SELECT: ",csv)
   
   SQL_Produit = db.query{api=db.SQL_SERVER,       
                          name="LogiDataTest", user="logidata", password="logidata",
                          sql='SELECT P.CodeProduit, P.Description, PF.CodeProduitFournisseur from Produit P '..
                              'LEFT JOIN ProduitsFournisseurs PF ON Pf.IDProduit = P.IDProduit '..
                              'where p.CodeProduit = '.."'"..csv[1].."'",live=true}

   -- For Debug purposes
   -- Permits to see whether the SQL query returns a results or a NULL value
   -- Marc Fellahi  2012/10/23  9:13
   trace("SQL Results: ", SQL_Produit[1].CodeProduit)

   csv[3] = EscapeValue(csv[3])
   csv[5] = EscapeValue(csv[5])
   csv[6] = EscapeValue(csv[6])
   csv[7] = EscapeValue(csv[7])
   csv[8] = EscapeValue(csv[8])
   
   if SQL_Produit:isNull() then

      -- For Debug purposes
      -- Permits to confirm that a NULL value has been encountered and that we are in the right loop
      -- Marc Fellahi  2012/10/23  9:13
      print("Item is non existent: ", csv[1])    
     
      db.execute{api=db.SQL_SERVER,
         name="LogiDataTest", user="logidata", password="logidata",
         sql=[[INSERT INTO Produit (CodeProduit, Description)]]..
             [[VALUES(']]..csv[1]..[[',]]..csv[3]..[[)]],live=true}
      
      
   else
      
      for i=1,#SQL_Produit do
 
         -- For Debug purposes
         -- Permits to confirm that the right record was encountered
         -- Marc Fellahi  2012/10/23  9:13
         --print("Data returned: ",SQL_Results[i].CodeProduit, SQL_Results[i].Description, SQL_Results[i].CodeProduitFournisseur)
         
         db.execute{api=db.SQL_SERVER,
            name="LogiDataTest", user="logidata", password="logidata",sql=[[UPDATE Produit ]]..
            [[SET Description =]] ..csv[3]..[[,]]..             
            [[ WHERE CodeProduit = ']]..csv[1]..[[']],live=true}
         
         SQL_Fournisseurs = db.query{api=db.SQL_SERVER,
                                     name="LogiDataTest",user="logidata",password="logidata",sql=[[SELECT Fournisseurs ]]..
                                     [[WHERE CodeFournisseur = ]]..csv[6],live=true}
         
         SQL_ProduitsFourn = db.query{api=db.SQL_SERVER,
                                      name="LogidataTest",user="logidata",password="logidata",sql=[[SELECT ProduitsFournisseurs ]]..
                                      [[where CodeFournisseur = ]]..csv[7],live=true}

         if SQL_Fournisseurs:isNull() then
            
            print("New vendor: ",csv[6]," Name: ",csv[5])
            
            db.execute{api=db.SQL_SERVER,
               name="LogidataTest",user"logidata", password="logidata",sql=[[INSERT INTO Fournisseurs VALUES(CodeFournisseurs,NomFournisseur) (]]..
               csv[6]..[[,]]..csv[5]..[[)]],live=true}
            
          end
            
          if SQL_ProduitsFourn:isNull() then
            
          
      end   
      
   end
   

end
