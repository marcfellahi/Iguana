require ('dbc') 
require ('files') 
 
DB = dbc.Connection{
   api=db.SQL_SERVER,
   name='LogidataTest',
   user='logidata',
   password='logidata'
}

-- Directory waiting for incoming messages 
-- <iguana install>\<INPUT_DIR>
INPUT_DIR = 'D:\\LogiData\\LogiDataV3\\TestEnv3.3\\McKesson\\Inbound'
-- Where to put files after processing 
ARCHIVED_DIR = 'D:\\LogiData\\LogiDataV3\\TestEnv3.3\\McKesson\\Archived'
-- file name/pattern to look for
FILE_PATTERN = '*.csv' 

-- check  incoming directory convert xls to CSV
-- parse CSV files, move files to processed directory
function main ()
   
   local DirectoryFiles = files.dir(INPUT_DIR,FILE_PATTERN)    
   -- Find the oldest file (not a directory)
   for k, v in pairs (DirectoryFiles) do 
      local FileName=INPUT_DIR.."\\"..v
      print(FileName)
      local ArchiveFileName=ARCHIVED_DIR.."\\"..os.date('%y%m%d%H%M%S')..v 
      print(ArchiveFileName)
      local File=io.open(FileName) 
      if (File) then 
         -- Not a directory 
         local S=File:read("*all")
         S=v..'\n'..S
         queue.push{data=S}
         io.close(File) 
         -- testing
         --local f=io.open(INPUT_DIR..'\\TestOut.txt', 'w')
         --f:write(S)
         --f:close()
         ---------
         if not iguana.isTest() then 
            os.rename(FileName,ArchiveFileName) 
         end 
      end 
   end 
   
end