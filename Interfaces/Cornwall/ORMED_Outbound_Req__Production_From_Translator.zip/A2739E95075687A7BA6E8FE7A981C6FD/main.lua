-- Change Request #1 - 2013/09/25  12:48
-- Updated the interface to fix a rare bug where the file would be in the process of being copied but not finalized and the interface would pick it up.
-- This would create duplicate items since it would only send what has been read.  Created the function OpenFile and used pcall to trap the error.  I 
-- also modified the flag for reading so that it does read and update instead of reading only.  There is a bug with pcall where even thought it receives 
-- Permission denied on reading the file, it still returns a status of true.  So we check if the fileopen is equal to nil.  If it is, that means the
-- file is not available and we get out of the process.  This check will continue until the file can be read and updated, thus avoid duplication of 
-- items.  Marc Fellahi
require('filehandling')
require('LdIguanaFileLibrary')
require('stringutil')
require('split')

local function trace(a,b,c,d) return end

local incomingfile       = [[.001]]
local sourcedirectory    = [[\\logid\Version\LogiDataRE\]]

trace(sourcedirectory)

function main()
   
   local data
   local filenames = scandir(sourcedirectory)

   if filenames ~= nil then
   
      for i=1,#filenames do
            
         uppername = filenames[i]:upper()

         if uppername:find(incomingfile) ~= nil then
            
            --k, j = uppername:find(incomingfile)
            
            local filetobeprocessed = string.upper(filenames[i])
            
            local Result = ProcessFile(sourcedirectory, filetobeprocessed)
            --print('Filename: ',sourcedirectory..filetobeprocessed)
            
            if Result == nil then
               return
            end
            
            if not iguana.isTest() then

               removeFile(sourcedirectory..filetobeprocessed)      
               
            end         
         end

      end

   end

end


function OpenFile(pathfile)

   return io.open(pathfile,'r+')
   
end


function ProcessFile(directory, file, replacedtext, deliverytext, striptextPO)

   local data           = ''
   local fileandpath    = directory..file
   
   --local fileopen = assert(io.open(fileandpath, "r"), "Could not open file: "..fileandpath)
   local Status, fileopen = pcall(OpenFile,fileandpath)
   
   if fileopen ~= nil then
      
      for line in fileopen:lines() do

         trace(line)
         data = data..line..'\r'
         trace(data)

      end

      trace(data)
      
      if not iguana.isTest() then
         
         queue.push{data=data}
         
      end

      io.close(fileopen)

   else
      
      return nil
      
   end
   
   --print('complete segment: ',data)

   return data

end

function scandir(directory)
   
   local counter = 1
   local nameindex = {}
   
   
   local filenames = io.popen('dir /b '..directory)
   trace(filenames)
   
   if filenames == nil then
      return nil
   end
   
   local list      = filenames:read('*a')
   
   trace(list)
   
   for k,v in pairs(list:split('\n')) do

      local listname = v:upper()
      
      if listname:find('.001') ~= nil then
      
         nameindex[counter] = v
         counter = counter + 1

      end
      
   end
   
   trace(nameindex)
      
   return nameindex
   
end 