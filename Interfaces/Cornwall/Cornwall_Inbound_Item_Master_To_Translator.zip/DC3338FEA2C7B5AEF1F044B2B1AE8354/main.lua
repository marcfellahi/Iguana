require('dbc')
require('DBOperations')
-- Maps the MSH segments to the tables Produit, Fournisseurs & ProduitsFournisseurs for McKesson 15.0
require('HL7-ORMED')  
require('iguanaconfig')
require('node')
require('retry')
require('sqlescape')
require('SMTPFunctions')
require("stringutil")

local function trace(a,b,c,d) return end
channel_info={}
strEscapedValues = sqlescape.EscapeFunction(db.SQL_SERVER)

function main(Data)

   local MessFile = io.open([[\\logid\Version\LogiDataExe\Interfaces\ORMED\messages.en.xml]])
   local MessFileRead = MessFile:read("*all")
   MessFile:close()
   
   local Inbound  = io.open([[\\logid\Version\LogiDataExe\Interfaces\ORMED\inboundsettings.xml]])
   local InboundFileRead = Inbound:read("*all") 
   Inbound:close()
   
   local Msg = {}
   Msg = Load_Messages(xml.parse{data=MessFileRead})
   
   local Settings = {}
   Settings = Load_Messages(xml.parse{data=InboundFileRead})    

   trace(Settings, Msg)
   
   local Message_Dir     = Settings.MessageDir[1]
   local MessageFileName = 'DataImport'..iguana.id()..'_1.csv'
   local vmdfile         = Settings.VMDFileMap[1]

   trace(Message_Dir, vmdfile)
   
   local ProcessedData = MapData(Data, vmdfile)

   -- tables (Produit, Fournisseurs, ProduitsFournisseurs) at the database level
   -- Marc Fellahi 2012/12/19  12:37PM
   local ReportingImport = ''
   
   if ProcessedData ~= nil then
      
       -- check if connection is valid an recreate if required
      -- (assume "conn" object was created earlier)      
      conn = dbc.Connection{         
         api=db.SQL_SERVER,
         name=Settings.DB_name[1],
         user=Settings.DB_username[1], 
         password=Settings.DB_password[1],
         use_unicode=true,
         live=true
         }

      DBStatus, ErrorString = pcall(SQLExecute, conn,'BEGIN TRANSACTION')

      if not DBStatus then
         
         print(Msg.Error_DBConn[1]..ErrorString) -- CONNECTION ERROR MESSAGE
         conn:close()
         return
         
      end
      
      TableUnits = {ProcessedData.Produit[1].UniteDistribution}
      if TableUnits[1] ~= ProcessedData.Produit[1].UniteEmballage then
         TableUnits[2] = ProcessedData.Produit[1].UniteEmballage       
      else
         if TableUnits[1] ~= ProcessedData.Produit[1].UniteAchat then
           TableUnits[2] = ProcessedData.Produit[1].UniteAchat
         end
      end
      
      trace(TableUnits)
      
      for i=1,#TableUnits do

         Status, ResultSQL = pcall(SQLQuery,conn,[[SELECT CodeUnite from Unites WHERE CodeUnite = ']]..TableUnits[i]..[[']])
   
         trace(Status,ResultSQL)
         if Status then
         
            if ResultSQL:isNull() then
            
               Status, ResultSQL = pcall(SQLExecute,conn,[[INSERT INTO Unites (CodeUnite) VALUES(']]..
                  TableUnits[i]..[[')]])
               
               ReportingImport = ReportingImport..','..TableUnits[i]..'\n'
         
               if not Status then
         
                  CloseDatabaseHandling(Msg.Error_InsertUnitesQueryFailed[1],conn,Msg)
                  return
                  
               end
               

            end
            
         else

            CloseDatabaseHandling(Msg.Error_SelectUnitesQueryFailed[1],conn,Msg)
            return                                
            
         end
         
      end

      for i = 1,#ProcessedData.Produit do

         -- These variables are used to determine if we allow updating of certain fields
         -- ModifDesc   = True permits the update of the product description in table Produit
         -- ModifQuotas = True permits the update of the quotas (Replenishment, distribution, etc.)
         -- Marc Fellahi  2013/01/14  10:35am
         local ModifDesc   = true
         local ModifQuotas = true
         local SendEmail   = false     
         
         -- These variables contain the results of SELECT, INSERT AND/OR UPDATES
         -- Marc Fellahi  2013/01/14  10:36am
         local ResultInsUpdFournisseur = ''         
         local ResultInsUpdProduit = ''
         local ResultInsUpdProduitFourn = ''
  
         -- These variables are used to store the values of the Identifty Field in
         -- Produit and Fournisseurs tables upon a successful SELECT at the DB
         -- level.  The values are necessary when doing INSERTS in ProduitsFournisseurs
         -- Marc Fellahi  2013/01/14  10:39am
         local strIdFournisseur = ''
         local strIdProduit = ''
         
         local strUpdInsFournisseur = ''
         local strUpdInsProdFourn = ''


         -- The values below are escaped to avoid any issues with insert and update statements (An extra quotation mark could 
         -- truncate the values and, as well, generate an SQL Error)  This is especially true with description fields
         -- (i.e.:  Scope 20' Black).  Before we escape the mapped values in ProcessedData          
         -- we need to store them in separate variables.  We need to do that in order to validate whether or not 
         local ProdCodeProduit   = ProcessedData.Produit[i].CodeProduit:nodeValue()
         local ProdDescription   = ProcessedData.Produit[i].Description:nodeValue()
         local CodeFournisseur   = ProcessedData.Fournisseurs[i].CodeFournisseur:nodeValue()
         local NomFournisseur    = ProcessedData.Fournisseurs[i].NomFournisseur:nodeValue()
         local CodeProduitFourn  = ProcessedData.ProduitsFournisseurs[i].CodeProduitFournisseur:nodeValue()
         ProcessedData.Produit[i].CodeProduit          = strEscapedValues(ProcessedData.Produit[i].CodeProduit:nodeValue())
         ProcessedData.Produit[i].Description          = strEscapedValues(ProcessedData.Produit[i].Description:nodeValue())
         ProcessedData.Fournisseurs[i].CodeFournisseur = strEscapedValues(ProcessedData.Fournisseurs[i].CodeFournisseur:nodeValue())
         ProcessedData.Fournisseurs[i].NomFournisseur  = strEscapedValues(ProcessedData.Fournisseurs[i].NomFournisseur:nodeValue())
         ProcessedData.ProduitsFournisseurs[i].CodeProduitFournisseur = 
            strEscapedValues(ProcessedData.ProduitsFournisseurs[i].CodeProduitFournisseur:nodeValue())
        
         local Status, ResultQueryProduit = pcall(SQLQuery,conn,[[SELECT P.IDProduit, P.CodeProduit, P.Description, P.UniteAchat, 
            CAST(CAST(P.Valeur as NUMERIC(10,4)) as varchar) as Valeur,
            P.UniteDistribution, P.UniteEmballage, P.QteEmballage
            FROM Produit P WHERE CodeProduit = ]]..ProcessedData.Produit[i].CodeProduit) 

         if Status then  -- Beginning of check for Status            
              
            if ResultQueryProduit:isNull() then -- Beginning of check for ResultQueryProduit:isNull()
               
               Status, ResultInsUpdProduit = 
                  pcall(SQLExecute,conn,[[INSERT INTO Produit (CodeProduit, Description, UniteDistribution, UniteAchat,]]..
                  [[Valeur,UniteEmballage,QteEmballage,UD3,CodeSpecialite, CodeSource, CodeFamille) VALUES(]]..
                  ProcessedData.Produit[i].CodeProduit..
                  [[,]]..ProcessedData.Produit[i].Description..               
                  [[,']]..ProcessedData.Produit[i].UniteDistribution..
                  [[',']]..ProcessedData.Produit[i].UniteAchat..
                  [[',']]..ProcessedData.Produit[i].Valeur..
                  [[',']]..ProcessedData.Produit[i].UniteEmballage..
                  [[',']]..ProcessedData.Produit[i].QteEmballage..
                  [[',']]..ProcessedData.Produit[i].UD3..
                  [[','$N','$N','$N')]])

               if Status then

                  Status, ResultQueryProduit = pcall(SQLQuery,conn,[[SELECT IdProduit FROM Produit WHERE CodeProduit = ]]
                     ..ProcessedData.Produit[i].CodeProduit)

                  if Status then
                    
                     ReportingImport = ReportingImport..Msg.Message_NewProductAdded[1]..','..
                     ProcessedData.Produit[i].CodeProduit..',,'..
                     ProcessedData.Produit[i].Description..'\n'
            
                     strIdProduit = ResultQueryProduit[1].IDProduit

                  else
                     
                     CloseDatabaseHandling(Msg.Error_SelectProductQueryFailed[1]..ResultQueryProduit,conn, Msg, Language)
                     return 
                     
                  end
                  
               else
                  
                  CloseDatabaseHandling(Msg.Error_InsertProductQueryFailed[1]..ResultInsUpdProduit,conn, Msg, Language)
                  return 
                  
               end
         
            else 

               if (ResultQueryProduit[1].Description:nodeValue() ~= ProdDescription) or
                  (ResultQueryProduit[1].UniteDistribution:nodeValue() ~= ProcessedData.Produit[i].UniteDistribution:nodeValue()) or
                  (ResultQueryProduit[1].UniteAchat:nodeValue() ~= ProcessedData.Produit[i].UniteAchat:nodeValue()) or
                  (ResultQueryProduit[1].QteEmballage:nodeValue() ~= ProcessedData.Produit[i].QteEmballage:nodeValue()) or
                  (ResultQueryProduit[1].Valeur:nodeValue() ~= ProcessedData.Produit[i].Valeur:nodeValue()) then
               
                  -- If there is one or more items that differ in the table with the incoming changes, we then
                  -- identify (this)(these) change(s) and appropriately build the SQL Update statement. This
                  -- section is also used to UPDATE only the required fields and report this information to the user
                  -- Marc Fellahi  2012/12/12
                  local NoUpdate = true
                  local SQLInsUpdProduit = [[UPDATE Produit SET ]]
                  local SQLperiod = ''
                  
                  if ResultQueryProduit[1].Description:nodeValue() ~= ProdDescription and ModifDesc then

                     SQLInsUpdProduit = SQLInsUpdProduit..[[Description = ]]..ProcessedData.Produit[i].Description:nodeValue()
                     SQLperiod = ','
                  
                     ReportingImport = ReportingImport..Msg.Message_ProdDescModified[1]..','
                     ..ProcessedData.Produit[i].CodeProduit:nodeValue()..', '
                     ..strEscapedValues(ResultQueryProduit[1].Description:nodeValue())..', '
                     ..ProcessedData.Produit[i].Description:nodeValue()..'\n'
                     
                     NoUpdate = false

                  end
               
                  if ResultQueryProduit[1].UniteDistribution:nodeValue() ~= ProcessedData.Produit[i].UniteDistribution:nodeValue() 
                     and ModifQuotas then
                 
                     SQLInsUpdProduit = SQLInsUpdProduit..SQLperiod..[[UniteDistribution = ']]
                     ..ProcessedData.Produit[i].UniteDistribution..[[']]
                     if SQLperiod == '' then
                        SQLperiod = ','
                     end

                     ReportingImport = ReportingImport..Msg.Message_ProdDistUnitModified[1]..','
                        ..ProcessedData.Produit[i].CodeProduit:nodeValue()
                        ..[[, ]]..ResultQueryProduit[1].UniteDistribution:nodeValue()
                        ..[[, ]]..ProcessedData.Produit[i].UniteDistribution:nodeValue()..'\n'

                     NoUpdate = false

                  end
               
                  if (ResultQueryProduit[1].UniteAchat:nodeValue() ~= ProcessedData.Produit[i].UniteAchat:nodeValue() or
                      ResultQueryProduit[1].UniteEmballage:nodeValue() ~= ProcessedData.Produit[i].UniteEmballage:nodeValue() or
                      ResultQueryProduit[1].QteEmballage:nodeValue() ~= ProcessedData.Produit[i].QteEmballage:nodeValue())
                     and ModifQuotas then
                 
                     SQLInsUpdProduit = SQLInsUpdProduit..SQLperiod..[[UniteAchat = ']]..ProcessedData.Produit[i].UniteAchat..
                     [[', UniteEmballage = ']]..ProcessedData.Produit[i].UniteEmballage..
                     [[', QteEmballage = ']]..ProcessedData.Produit[i].QteEmballage..
                     [[', UD3 = ']]..ProcessedData.Produit[i].UD3..[[']]

                     if SQLperiod == '' then
                        SQLperiod = ','
                     end     
                  
                     ReportingImport = ReportingImport..Msg.Message_ProdQuotasModified[1]..','
                        ..ProcessedData.Produit[i].CodeProduit:nodeValue()..','
                        ..ResultQueryProduit[1].UniteAchat:nodeValue()..' '
                        ..ResultQueryProduit[1].UniteEmballage:nodeValue()..' '
                        ..ResultQueryProduit[1].QteEmballage:nodeValue()..','
                        ..ProcessedData.Produit[i].UniteAchat:nodeValue()..' '
                        ..ProcessedData.Produit[i].UniteEmballage:nodeValue()..' '
                        ..ProcessedData.Produit[i].QteEmballage:nodeValue()..'\n'

                     NoUpdate = false

                  end

                  --trace(round(ResultQueryProduit[1].Valeur:nodeValue(),2) ~= round(ProcessedData.Produit[i].Valeur:nodeValue(),2))
                  
                  if ResultQueryProduit[1].Valeur:nodeValue() ~= ProcessedData.Produit[i].Valeur:nodeValue()                     
                     and ModifQuotas then              
                     
                     SQLInsUpdProduit = SQLInsUpdProduit..SQLperiod..[[Valeur = ']]..ProcessedData.Produit[i].Valeur:nodeValue()..[[']]
                  
                     ReportingImport = ReportingImport..Msg.Message_ProdValueModified[1]..','..
                     ProcessedData.Produit[i].CodeProduit:nodeValue()..','..
                     ResultQueryProduit[1].Valeur:nodeValue()..','..
                     ProcessedData.Produit[i].Valeur:nodeValue()..'\n'

                     NoUpdate = false

                  end

                  -- Since the UPDATE is built conditionnaly, there is a possibility that nothing is updated.  To avoid that
                  -- we use the boolean variable NoUpdate.  If set to true, then we run the UPDATE else we bypass it
                  -- Marc Fellahi  2012/01/11  14:35pm
                  if not NoUpdate then
 
                     Status, ResultInsUpdProduit = pcall(SQLExecute,conn,SQLInsUpdProduit..
                        [[ WHERE CodeProduit = ]]..ProcessedData.Produit[i].CodeProduit:nodeValue())
              
                     if not Status then
                     
                        CloseDatabaseHandling(Msg.Error_UpdateProductQueryFailed[1]..ResultInsUpdProduit,conn, Msg, Language)
                        return
                     
                     end
 
                  end
 
               end -- End of if ResultQueryProduit:isNull()
            
               strIdProduit = ResultQueryProduit[1].IDProduit
            
            end -- end of if for insert or update in Produit table
            
         else
 
            CloseDatabaseHandling(Msg.Error_SelectProductQueryFailed[1]..ResultQueryProduit,conn, Msg, Language)
            return
            
         end  -- End of check for StatusProduit
            
         Status, ResultQueryFourn = pcall(SQLQuery,conn,
            [[SELECT idFournisseurs, CodeFournisseur, NomFournisseur FROM Fournisseurs WHERE CodeFournisseur = ]]
            ..ProcessedData.Fournisseurs[i].CodeFournisseur)
         
         if Status then  -- Beginning of check for StatusFourn
            
            if ResultQueryFourn[1].IdFournisseurs:isNull() then
           
               Status, ResultInsUpdProduitFourn = pcall(SQLExecute,conn,
                  [[INSERT INTO Fournisseurs (CodeFournisseur,NomFournisseur) VALUES(]]..
                  ProcessedData.Fournisseurs[i].CodeFournisseur..[[,]]..ProcessedData.Fournisseurs[i].NomFournisseur..[[)]])
           
               if Status then
                  
                  Status, ResultQueryFourn = pcall(SQLQuery,conn,[[SELECT idFournisseurs FROM Fournisseurs
                     WHERE CodeFournisseur = ]]..ProcessedData.Fournisseurs[i].CodeFournisseur)

                  if Status then
                     
                     ReportingImport = ReportingImport..Msg.Message_VendorAdded[1]..','..
                        ProcessedData.Fournisseurs[i].CodeFournisseur:nodeValue()..' '..
                        ProcessedData.Fournisseurs[i].NomFournisseur:nodeValue()..'\n'
                     
                  else
                     
                     CloseDatabaseHandling(Msg.Error_SelectVendorQueryFailed[1]..ResultQueryFourn,conn, Msg, Language)
                     return
                     
                  end

               else
                  
                  CloseDatabaseHandling(Msg.Error_InsertVendorQueryFailed[1]..ResultQueryFourn,conn, Msg, Language)
                  return
                  
               end
               
            else

               if ResultQueryFourn[1].NomFournisseur:nodeValue() ~= NomFournisseur or
                  ResultQueryFourn[1].CodeFournisseur:nodeValue() ~= CodeFournisseur then
               
                  local SQLUpdateFourn = [[UPDATE Fournisseurs SET ]]
                  local SQLperiod = ''

                  NoUpdate = true 
                  
                  if ResultQueryFourn[1].NomFournisseur:nodeValue() ~= NomFournisseur then
                     
                     SQLUpdateFourn = SQLUpdateFourn..[[NomFournisseur = ]]..ProcessedData.Fournisseurs[i].NomFournisseur
                     SQLperiod = ','

                     ReportingImport = ReportingImport..Msg.Message_VendorNameUpdated[1]..','..
                     ResultQueryFourn[1].CodeFournisseur:nodeValue()..', '..
                     ResultQueryFourn[1].NomFournisseur:nodeValue()..', '..
                     ProcessedData.Fournisseurs[i].NomFournisseur..'\n'

                     NoUpdate = false
                     
                  end
 
                  if ResultQueryFourn[1].CodeFournisseur:nodeValue() ~= CodeFournisseur then
                  
                     SQLUpdateFourn = SQLUpdateFourn..SQLperiod..[[CodeFournisseur = ]]..
                     ProcessedData.Fournisseurs[i].CodeFournisseur
                     
                     ReportingImport = ReportingImport..Msg.Message_VendorCodeUpdated[1]..','..
                     ProcessedData.Produit[i].CodeProduit..','..
                     ResultQueryFourn[1].CodeFournisseur:nodeValue()', '..
                     ProcessedData.Fournisseurs[i].CodeFournisseur..'\n'
                  
                     NoUpdate = false
                     
                  end
               
                  SQLUpdateFourn = SQLUpdateFourn..[[ WHERE CodeFournisseur = ]]..ProcessedData.Fournisseurs[i].CodeFournisseur

                  if not NoUpdate then
                     
                     Status, ResultInsUpdProduitFourn = pcall(SQLExecute,conn,SQLUpdateFourn)
                  
                     if not Status then
 
                        CloseDatabaseHandling(Msg.Error_UpdateVendorQueryFailed[1]..ResultInsUpdProduitFourn,
                           conn, Msg, Language)
                        return
                     
                     end
 
                  end
                  
               else
               
                  strUpdInsFournisseur = ''
               
               end

            end

            strIdFournisseur = ResultQueryFourn[1].idFournisseurs:nodeValue()
            
         else
            
            CloseDatabaseHandling(Msg.Error_SelectVendorQueryFailed[1]..ResultQueryFourn, conn, Msg, Language)
            return
         
         end  -- End of check for StatusFourn
            
         Status, ResultQueryProduitFourn = pcall(SQLQuery, conn,
            [[SELECT PF.IdFournisseurs, F.CodeFournisseur, F.NomFournisseur, PF.CodeProduitFournisseur ]]..
            [[FROM ProduitsFournisseurs PF ]]..
            [[JOIN Fournisseurs F ON F.IdFournisseurs = PF.IdFournisseurs ]]..
            [[WHERE PF.IdProduit = ]]..strIdProduit)
         
         if Status then 

            if ResultQueryProduitFourn:isNull() then

               Status, strUpdInsFourn = pcall(SQLExecute, conn,
                  [[INSERT INTO ProduitsFournisseurs (IdFournisseurs, IdProduit, CodeProduitFournisseur)
                  VALUES(']]..strIdFournisseur..[[',']]..strIdProduit..[[',]]
                  ..ProcessedData.ProduitsFournisseurs[i].CodeProduitFournisseur..[[)]])

               if Status then
                  
                  ReportingImport = ReportingImport..Msg.Message_NewVendorProdCodeAdded[1]..','..
                  ProcessedData.Produit[i].CodeProduit..',,'..
                  ProcessedData.ProduitsFournisseurs[i].CodeProduitFournisseur..'\n'
                  
               else
                  
                  CloseDatabaseHandling(Msg.Error_InsertVendorProdCodeQueryFailed[1]..strUpdInsFourn,conn,Msg, Language)
                  return
                
               end
            
            else
               
               trace(CodeProduitFourn,strIdFournisseur)
                  
               if ResultQueryProduitFourn[1].CodeProduitFournisseur:nodeValue() ~= CodeProduitFourn or
                  ResultQueryProduitFourn[1].idFournisseurs:nodeValue() ~= strIdFournisseur then
           
                  Status, strUpdInsFourn = pcall(SQLExecute,conn,
                     [[UPDATE ProduitsFournisseurs SET idFournisseurs = ]]..
                     strIdFournisseur..[[, CodeProduitFournisseur = ]]
                     ..ProcessedData.ProduitsFournisseurs[i].CodeProduitFournisseur.. 
                     [[ WHERE IdProduit = ]]..strIdProduit)
           
                  if Status then
                     
                     if ResultQueryProduitFourn[1].CodeProduitFournisseur:nodeValue() ~= CodeProduitFourn then
                        
                        ReportingImport = ReportingImport..Msg.Message_VendorProdCodeUpdated[1]..','..
                        ProcessedData.Produit[i].CodeProduit..','..
                        ResultQueryProduitFourn[1].CodeProduitFournisseur:nodeValue()..','..
                        ProcessedData.ProduitsFournisseurs[i].CodeProduitFournisseur:nodeValue()..'\n'

                     end
                     
                     if ResultQueryProduitFourn[1].idFournisseurs:nodeValue() ~= strIdFournisseur then
                        
                        ReportingImport = ReportingImport..Msg.Message_VendorCodeUpdated[1]..','..
                        ProcessedData.Produit[i].CodeProduit..','..
                        ResultQueryProduitFourn[1].CodeFournisseur..' '..
                        ResultQueryProduitFourn[1].NomFournisseur..','..
                        ProcessedData.Fournisseurs[i].CodeFournisseur..' '..
                        ProcessedData.Fournisseurs[i].NomFournisseur..'\n'                      
                                                
                     end

                  else

                     CloseDatabaseHandling(Msg.Error_UpdateVendorProdCodeQueryFailed[1]..StrUpdInsFourn,conn, Msg, Language)
                     return
                     
                  end
           
               end
            
            end
            
         else
            
            CloseDatabaseHandling(Msg.Error_SelectVendorProdCodeQueryFailed[1]..ResultQueryProduitFourn,conn, Msg, Language)
            return
            
         end

      end

      Status, ErrorString = pcall(SQLExecute,conn,'COMMIT TRANSACTION')
      
      if not Status then
   
         print(Msg.Error_DBCommit[1]..ErrorString)
         
      end

      trace(Settings,Msg.Reporting_Header[1]..'\n'..Msg.Reporting_Nochanges[1]..'\n',Message_Dir..MessageFileName)
      
      conn:close() 

   end 
   
      local MessagesinQueue = MessagesQueued(iguana.channelName())
 
      if not iguana.isTest() then
      --if iguana.isTest() then
         
         if ReportingImport ~= '' then
         
            local Status, LogFile = pcall(io.open,Message_Dir..MessageFileName,'a+')
         
            if Status then
            
               if LogFile ~= nil then
            
                  local LogSize = LogFile:seek('end')
   
                  if LogSize == 0 then

                     local DateLog = 'Date: '..os.date('%A'..' '..'%B'..' '..'%d'..' '..'%Y')
                     LogFile:write('\n','Change Alert Type,Item,Previous value(s),New value(s)',DateLog,'\n') 
                  
                  end
            
                  LogFile:write(ReportingImport)
             
               end
            
               LogFile:close()
         
            
            else
            
               print('Could not open Log File!')

            end
         

         end
      

         if MessagesinQueue ~= nil then

            if MessagesinQueue == 1 then
         
               --print(Inbound_Report.getTableState())
            
               --Inbound_Report.drop()
            
               local Status, LogFile = pcall(io.open,Message_Dir..MessageFileName,'a+')
              
               if Status then

                  if LogFile ~= nil then
                  
                     local LogSize = LogFile:seek('end')
                  
                     if LogSize == 0 then

                        local DateLog = 'Date: '..os.date('%A'..' '..'%B'..' '..'%d'..' '..'%Y')
                        LogFile:write('\n','Change Alert Type,Item,Previous value(s),New value(s)',DateLog,'\n',
                        'There are no reported changes')

                     end                    

                     LogFile:seek('set')
                     local LogEntries = LogFile:read('*all')
                     LogFile:close()
                  
                     if SendEmail then
                     
                        retry.call{func=mime.send,arg1={server=[[smtp://132.147.1.9:25/]],username=[[logidalerts]],
                        password='southlake4521',from='logidalerts@southlakeregional.org',to={'lkirby@southlakeregional.org',
                          'marc.fellahi@logi-d.net','tmingo@southlakeregional.org'},
                        --password=[[southlake4521]],from=[[logidalerts@southlakeregional.org]],to={[[marc.fellahi@logi-d.net]]},
                        header={['Subject']=[[Inbound Report for ]]..os.date("%x")},body=[[CSV file attached to email]], 
                        use_ssl=[[try]],timeout=120,attachments={Message_Dir..MessageFileName}},
                        retry=5,pause=30}
                     
                     end

                     iguana.logInfo(Msg.Message_InboundReport[1]..LogEntries)
                  
                  else
                  
                     LogFile:close()                  

                  end

               end
           
               local Status, RemoveFile = pcall(os.remove,Message_Dir..MessageFileName)
            
            end
         
         end

      end
      
end