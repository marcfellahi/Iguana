require('filehandling')
require('LdIguanaFileLibrary')
require('stringutil')

local function trace(a,b,c,d) return end

local incomingfile       = [[.001]]
local sourcedirectory    = [[\\logid\TestEnv\LogiDataRE\]]

trace(sourcedirectory)

function main()
   
   local data
   local filenames = scandir(sourcedirectory)

   if filenames ~= nil then
   
      for i=1,#filenames do
            
         uppername = filenames[i]:upper()

         if uppername:find(incomingfile) ~= nil then
            
            --k, j = uppername:find(incomingfile)
            
            local filetobeprocessed = string.upper(filenames[i])
            --print('Filename: ',filetobeprocessed)

            local Result = ProcessFile(sourcedirectory, filetobeprocessed)
              
            if Result == nil then
               return
            end
               
            if not iguana.isTest() then

               removeFile(sourcedirectory..filetobeprocessed)      
               
            end         
            
         end

      end

   end

end


function OpenError(x)

   return x
   
end


function OpenFile(pathfile)

   return io.open(pathfile,'r+')
   
end


function ProcessFile(directory, file, replacedtext, deliverytext, striptextPO)

   local data           = ''
   local fileandpath    = directory..file
   
   --local fileopen = assert(io.open(fileandpath, "r+"), "Could not open file: "..fileandpath)
   local Status, fileopen = pcall(OpenFile,fileandpath)
   
   trace(Status, fileopen, Errmsg)
   
   if fileopen ~= nil then
      
      for line in fileopen:lines() do

         trace(line)
         data = data..line..'\r'
         trace(data)

      end

      trace(data)
      
      queue.push{data=data}

      io.close(fileopen)
   
   else 
      
      return nil
               
   end
   
   --print('complete segment: ',data)

   return data

end

function scandir(directory)
   
   local counter = 1
   local nameindex = {}
   
   
   local filenames = io.popen('dir /b '..directory)
   trace(filenames)
   local list      = filenames:read('*a')
   
   for k,v in pairs(list:split('\n')) do

      local listname = v:upper()
      
      if listname:find('.001') ~= nil then
      
         nameindex[counter] = v
         counter = counter + 1

      end
      
   end
   
   trace(nameindex)
      
   return nameindex
   
end 